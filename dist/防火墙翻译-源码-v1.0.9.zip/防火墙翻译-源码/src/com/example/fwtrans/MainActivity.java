package com.example.fwtrans;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final String[] VENDORS = new String[]{
            "华为 USG", "华三 H3C", "飞塔 Fortinet", "山石 Hillstone", "Palo Alto", "Cisco ASA"
    };

    private String srcVendor = VENDORS[0];
    private String dstVendor = VENDORS[2];

    private final List<TextView> srcChips = new ArrayList<>();
    private final List<TextView> dstChips = new ArrayList<>();

    private EditText input;
    private LinearLayout resultBox;
    private String resultAll = "";
    private final String[] secNames = new String[]{"地址对象", "服务对象", "策略", "NAT"};
    private String[] secCache = new String[4];
    private Model secModel;
    private LinearLayout secTabs;
    private TextView secBody;
    private TextView secCount;
    private TextView secCopy;
    private int secIndex = 0;
    private LinearLayout noteBox;
    private TextView noteTitle;
    private TextView convertBtn;

    private boolean dark;
    private OtaManager otaManager;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        otaManager = new OtaManager(this);
        int mode = prefs().getInt("night_mode", 0);
        boolean sysNight = (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        dark = mode == 2 || (mode == 0 && sysNight);
        applyImmersiveStatusBar();
        buildUi();
    }

    /** 沉浸式：内容顶到状态栏下方，状态栏透明、图标随主题反色 */
    private void applyImmersiveStatusBar() {
        android.view.Window w = getWindow();
        w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            w.setNavigationBarColor(0x00000000);
        }
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | (dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    // ---------------- 配色 ----------------
    private int cBg() { return dark ? 0xFF0F1319 : 0xFFF5F7FB; }
    private int cCard() { return dark ? 0xFF1A212C : 0xFFFFFFFF; }
    private int cSoft() { return dark ? 0xFF232C3A : 0xFFEDF1F7; }
    private int cText() { return dark ? 0xFFE8EDF5 : 0xFF16202E; }
    private int cSub() { return dark ? 0xFF95A3B8 : 0xFF6B7A8E; }
    private int cAccent() { return 0xFF2F6BFF; }
    private int cHair() { return dark ? 0xFF2C3646 : 0xFFE2E8F0; }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private GradientDrawable round(int color, float r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(r));
        return d;
    }

    private GradientDrawable roundStroke(int color, float r, int strokeColor) {
        GradientDrawable d = round(color, r);
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    // ---------------- 界面 ----------------
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(cBg());
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), statusBarHeight() + dp(14), dp(18), dp(28));
        scroll.addView(root);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout headTexts = new LinearLayout(this);
        headTexts.setOrientation(LinearLayout.VERTICAL);
        headTexts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText("防火墙翻译");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(cText());
        headTexts.addView(title);

        TextView sub = new TextView(this);
        sub.setText("配置互通转换 · 地址 / 服务 / 策略 / NAT");
        sub.setTextSize(12);
        sub.setTextColor(cSub());
        sub.setPadding(0, dp(4), 0, 0);
        headTexts.addView(sub);

        head.addView(headTexts);

        TextView gear = new TextView(this);
        gear.setText("⚙");
        gear.setTextSize(17);
        gear.setTextColor(cSub());
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(round(cSoft(), 14));
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(40), dp(40));
        gear.setLayoutParams(glp);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        head.addView(gear);

        root.addView(head);

        TextView gap = new TextView(this);
        gap.setText("");
        gap.setHeight(dp(16));
        root.addView(gap);

        // 源厂商
        root.addView(label("源设备"));
        srcChips.clear();
        root.addView(chipRows(VENDORS, true));

        // 交换按钮
        TextView swap = new TextView(this);
        swap.setText("⇅  交换源 / 目标");
        swap.setTextSize(12);
        swap.setTextColor(cAccent());
        swap.setGravity(Gravity.CENTER);
        swap.setPadding(0, dp(10), 0, dp(10));
        swap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = srcVendor;
                srcVendor = dstVendor;
                dstVendor = t;
                paintChips();
            }
        });
        root.addView(swap);

        // 目标厂商
        root.addView(label("目标设备"));
        dstChips.clear();
        root.addView(chipRows(VENDORS, false));

        // 输入
        LinearLayout inputHead = new LinearLayout(this);
        inputHead.setOrientation(LinearLayout.HORIZONTAL);
        inputHead.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ihlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ihlp.topMargin = dp(12);
        inputHead.setLayoutParams(ihlp);

        TextView inLabel = new TextView(this);
        inLabel.setText("源配置");
        inLabel.setTextSize(12);
        inLabel.setTypeface(Typeface.DEFAULT_BOLD);
        inLabel.setTextColor(cSub());
        inLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        inputHead.addView(inLabel);

        TextView importBtn = new TextView(this);
        importBtn.setText("＋ 导入文件");
        importBtn.setTextSize(12);
        importBtn.setTextColor(cAccent());
        importBtn.setPadding(dp(10), dp(6), dp(6), dp(6));
        importBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickConfigFile();
            }
        });
        inputHead.addView(importBtn);

        root.addView(inputHead);

        input = new EditText(this);
        input.setHint("粘贴配置，或点右上「导入文件」选择 conf / txt / log 等文本");
        input.setHintTextColor(cSub());
        input.setTextColor(cText());
        input.setTextSize(11.5f);
        input.setTypeface(Typeface.MONOSPACE);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setBackground(roundStroke(cCard(), 14, cHair()));
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        input.setMinLines(8);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(190));
        ilp.topMargin = dp(8);
        input.setLayoutParams(ilp);
        root.addView(input);

        // 转换按钮
        convertBtn = new TextView(this);
        convertBtn.setText("开始转换");
        convertBtn.setTextSize(15);
        convertBtn.setTypeface(Typeface.DEFAULT_BOLD);
        convertBtn.setTextColor(0xFFFFFFFF);
        convertBtn.setGravity(Gravity.CENTER);
        convertBtn.setBackground(round(cAccent(), 16));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        blp.topMargin = dp(14);
        convertBtn.setLayoutParams(blp);
        convertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });
        root.addView(convertBtn);

        // 结果
        LinearLayout resultHead = new LinearLayout(this);
        resultHead.setOrientation(LinearLayout.HORIZONTAL);
        resultHead.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rhlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rhlp.topMargin = dp(20);
        resultHead.setLayoutParams(rhlp);

        TextView rt = new TextView(this);
        rt.setText("转换结果");
        rt.setTextSize(13);
        rt.setTypeface(Typeface.DEFAULT_BOLD);
        rt.setTextColor(cText());
        rt.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        resultHead.addView(rt);

        TextView copy = new TextView(this);
        copy.setText("复制");
        copy.setTextSize(12);
        copy.setTextColor(cAccent());
        copy.setPadding(dp(10), dp(6), dp(4), dp(6));
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyResult();
            }
        });
        resultHead.addView(copy);

        TextView share = new TextView(this);
        share.setText("分享");
        share.setTextSize(12);
        share.setTextColor(cAccent());
        share.setPadding(dp(10), dp(6), dp(4), dp(6));
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareResult();
            }
        });
        resultHead.addView(share);

        root.addView(resultHead);

        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rblp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rblp.topMargin = dp(8);
        resultBox.setLayoutParams(rblp);
        resultBox.setVisibility(View.GONE);
        root.addView(resultBox);

        // 未转换项
        noteTitle = new TextView(this);
        noteTitle.setText("需要人工确认的项目");
        noteTitle.setTextSize(13);
        noteTitle.setTypeface(Typeface.DEFAULT_BOLD);
        noteTitle.setTextColor(0xFFE59A1E);
        LinearLayout.LayoutParams ntlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ntlp.topMargin = dp(18);
        noteTitle.setLayoutParams(ntlp);
        noteTitle.setVisibility(View.GONE);
        root.addView(noteTitle);

        noteBox = new LinearLayout(this);
        noteBox.setOrientation(LinearLayout.VERTICAL);
        noteBox.setBackground(round(dark ? 0xFF241E12 : 0xFFFFF6E6, 14));
        noteBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nlp.topMargin = dp(6);
        noteBox.setLayoutParams(nlp);
        noteBox.setVisibility(View.GONE);
        root.addView(noteBox);

        // 版本信息收进设置面板
        setContentView(scroll);
        paintChips();
    }

    @Override
    protected void onDestroy() {
        if (otaManager != null) otaManager.release();
        super.onDestroy();
    }

    private String versionName() {
        try {
            android.content.pm.PackageInfo pi = getPackageManager()
                    .getPackageInfo(getPackageName(), 0);
            return pi.versionName;
        } catch (Throwable t) {
            return "1.0.0";
        }
    }

    private static final int REQ_PICK_CONFIG = 1001;

    /** 打开系统文件选择器，读取配置文本 */
    private void pickConfigFile() {
        try {
            Intent it = new Intent(Intent.ACTION_GET_CONTENT);
            it.addCategory(Intent.CATEGORY_OPENABLE);
            it.setType("*/*");
            it.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "text/plain", "text/*", "application/octet-stream",
                    "application/x-config", "*/*"});
            startActivityForResult(Intent.createChooser(it, "选择配置文件"), REQ_PICK_CONFIG);
        } catch (Exception e) {
            Toast.makeText(this, "打不开文件选择器：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_CONFIG || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        String name = displayName(uri);
        try {
            String text = readText(uri);
            if (text == null || text.trim().isEmpty()) {
                Toast.makeText(this, "这个文件是空的", Toast.LENGTH_SHORT).show();
                return;
            }
            input.setText(text);
            input.setSelection(0);
            int lines = text.split("\n").length;
            Toast.makeText(this, "已导入 " + name + "（" + lines + " 行）",
                    Toast.LENGTH_SHORT).show();
            int guess = guessVendor(text);
            if (guess >= 0 && !VENDORS[guess].equals(srcVendor)) {
                srcVendor = VENDORS[guess];
                paintChips();
                Toast.makeText(this, "已按内容识别源设备：" + srcVendor,
                        Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "读取失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /** 根据配置里的关键字猜源厂商 */
    private int guessVendor(String text) {
        String t = text.toLowerCase();
        if (t.contains("config system interface") || t.contains("config firewall policy")
                || t.contains("set dstintf")) return 2;          // 飞塔
        if (t.contains("security-zone") || t.contains("policy from")
                || t.contains("address-book")) {
            if (t.contains("zone \"") || t.contains("set src zone")) return 3;   // 山石
            return 0;                                          // 华为
        }
        if (t.contains("set address") || t.contains("set rulebase")
                || t.contains("set zone trust")) return 4;     // PA
        if (t.contains("access-list") || t.contains("object-group")
                || t.contains(": end") || t.contains("interface ethernet")) return 5; // ASA
        if (t.contains("nat outbound") || t.contains("acl number")
                || t.contains("security-policy")) return 1;    // 华三
        if (t.contains("#")) return -1;
        return -1;
    }

    private String displayName(Uri uri) {
        try {
            android.database.Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                        if (idx >= 0) {
                            String n = c.getString(idx);
                            if (n != null && !n.isEmpty()) return n;
                        }
                    }
                } finally {
                    c.close();
                }
            }
        } catch (Exception ignored) {
        }
        String p = uri.getPath();
        return p != null ? p : "配置";
    }

    /** 兜底：UTF-8 读不出中文时按 GBK 再试一次 */
    private String readText(Uri uri) throws Exception {
        java.io.InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("无法打开文件");
        try {
            byte[] buf = new byte[8192];
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 4 * 1024 * 1024) throw new Exception("文件超过 4 MB，请裁短后再导入");
                bos.write(buf, 0, n);
            }
            byte[] bytes = bos.toByteArray();
            String utf8 = new String(bytes, "UTF-8");
            if (new String(utf8.getBytes("UTF-8"), "UTF-8").equals(utf8)
                    && !utf8.contains("\uFFFD")) return utf8;
            return new String(bytes, "GBK");
        } finally {
            try { in.close(); } catch (Exception ignored) { }
        }
    }

    /** 设置面板：检查更新 / OTA下载记录 */
    private void showSettings() {
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(dp(18), dp(24), dp(18), dp(24));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(round(cCard(), 22));
        card.setPadding(0, dp(18), 0, dp(8));

        TextView t = new TextView(this);
        t.setText("设置");
        t.setTextSize(19);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(cText());
        t.setPadding(dp(20), 0, dp(20), dp(3));
        card.addView(t);

        TextView ver = new TextView(this);
        ver.setText("防火墙翻译 v" + versionName());
        ver.setTextSize(12);
        ver.setTextColor(cSub());
        ver.setPadding(dp(20), 0, dp(20), dp(12));
        card.addView(ver);

        final Dialog[] dlg = new Dialog[1];

        card.addView(nightModeRow());

        card.addView(settingRow("检查更新", "当前版本 v" + versionName(), "检查", false,
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (dlg[0] != null) dlg[0].dismiss();
                        otaManager.checkUpdate(true);
                    }
                }));

        card.addView(paFormatRow());

        card.addView(settingRow("OTA下载记录",
                OtaManager.isDownloadingStatic() ? "正在下载更新，点查看可回到进度" : "查看已下载的安装包，可删除源文件",
                "查看", true, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (dlg[0] != null) dlg[0].dismiss();
                        if (OtaManager.isDownloadingStatic()) {
                            otaManager.reopenProgress();
                        } else {
                            otaManager.showRecords();
                        }
                    }
                }));

        TextView close = new TextView(this);
        close.setText("完成");
        close.setTextSize(14.5f);
        close.setTextColor(cSub());
        close.setGravity(Gravity.CENTER);
        close.setPadding(0, dp(12), 0, dp(10));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dlg[0] != null) dlg[0].dismiss();
            }
        });
        card.addView(close);

        wrap.addView(card, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Dialog d = new Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.setContentView(wrap);
        android.view.Window win = d.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            win.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.92f),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dlg[0] = d;
        d.show();
    }

    /** 设置项：夜间模式 跟随系统 / 浅色 / 深色 */
    private View nightModeRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setBackground(round(cSoft(), 14));
        row.setPadding(dp(12), dp(11), dp(12), dp(11));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.leftMargin = dp(10);
        rlp.rightMargin = dp(10);
        rlp.bottomMargin = dp(4);
        row.setLayoutParams(rlp);

        TextView tt = new TextView(this);
        tt.setText("夜间模式");
        tt.setTextSize(14.5f);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setTextColor(cText());
        row.addView(tt);

        TextView ss = new TextView(this);
        ss.setText("「跟随系统」按手机深色开关自动切换");
        ss.setTextSize(11.5f);
        ss.setTextColor(cSub());
        ss.setPadding(0, dp(3), 0, dp(8));
        row.addView(ss);

        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        final int current = prefs().getInt("night_mode", 0);
        String[] names = new String[]{"跟随系统", "浅色", "深色"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView chip = new TextView(this);
            chip.setText(names[i]);
            chip.setTextSize(12.5f);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(0, dp(8), 0, dp(8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.rightMargin = i < 2 ? dp(8) : 0;
            chip.setLayoutParams(lp);
            chip.setBackground(idx == current ? round(cAccent(), 11) : round(cCard(), 11));
            chip.setTextColor(idx == current ? 0xFFFFFFFF : cText());
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (idx == prefs().getInt("night_mode", 0)) return;
                    prefs().edit().putInt("night_mode", idx).apply();
                    recreate();
                }
            });
            seg.addView(chip);
        }
        row.addView(seg);
        return row;
    }

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences("fwtrans", MODE_PRIVATE);
    }

    private boolean paSetFormat() {
        return prefs().getBoolean("pa_set", true);
    }

    private void setPaSetFormat(boolean v) {
        prefs().edit().putBoolean("pa_set", v).apply();
    }

    /** 设置项：PA 输出格式 XML / set */
    private View paFormatRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setBackground(round(cSoft(), 14));
        row.setPadding(dp(12), dp(11), dp(12), dp(11));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.leftMargin = dp(10);
        rlp.rightMargin = dp(10);
        rlp.bottomMargin = dp(4);
        row.setLayoutParams(rlp);

        TextView tt = new TextView(this);
        tt.setText("PA 输出格式");
        tt.setTextSize(14.5f);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setTextColor(cText());
        row.addView(tt);

        TextView ss = new TextView(this);
        ss.setText("目标为 Palo Alto 时用 set 命令还是 XML");
        ss.setTextSize(11.5f);
        ss.setTextColor(cSub());
        ss.setPadding(0, dp(3), 0, dp(8));
        row.addView(ss);

        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);

        final TextView xmlChip = paChip("XML");
        final TextView setChip = paChip("set 命令");
        xmlChip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPaSetFormat(false);
                paintPaChips(xmlChip, setChip);
            }
        });
        setChip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPaSetFormat(true);
                paintPaChips(xmlChip, setChip);
            }
        });
        seg.addView(setChip);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        slp.rightMargin = dp(8);
        setChip.setLayoutParams(slp);
        seg.addView(xmlChip);
        xmlChip.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(seg);

        paintPaChips(xmlChip, setChip);
        return row;
    }

    private TextView paChip(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(12.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, dp(8));
        return t;
    }

    private void paintPaChips(TextView xmlChip, TextView setChip) {
        boolean set = paSetFormat();
        setChip.setBackground(set ? round(cAccent(), 11) : round(cCard(), 11));
        setChip.setTextColor(set ? 0xFFFFFFFF : cText());
        xmlChip.setBackground(!set ? round(cAccent(), 11) : round(cCard(), 11));
        xmlChip.setTextColor(!set ? 0xFFFFFFFF : cText());
    }

    private View settingRow(String title, String sub, String action, boolean last,
                            View.OnClickListener onAction) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(11), dp(12), dp(11));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(last ? (dark ? 0xFF202834 : 0xFFF6F8FC) : cSoft());
        bg.setCornerRadius(dp(14));
        row.setBackground(bg);

        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.leftMargin = dp(10);
        rlp.rightMargin = dp(10);
        rlp.bottomMargin = dp(4);
        row.setLayoutParams(rlp);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tt = new TextView(this);
        tt.setText(title);
        tt.setTextSize(14.5f);
        tt.setTypeface(Typeface.DEFAULT_BOLD);
        tt.setTextColor(cText());
        texts.addView(tt);

        TextView ss = new TextView(this);
        ss.setText(sub);
        ss.setTextSize(11.5f);
        ss.setTextColor(cSub());
        ss.setPadding(0, dp(3), 0, 0);
        texts.addView(ss);

        row.addView(texts);

        TextView act = new TextView(this);
        act.setText(action);
        act.setTextSize(12.5f);
        act.setTextColor(cAccent());
        act.setPadding(dp(10), dp(8), dp(8), dp(8));
        act.setOnClickListener(onAction);
        row.addView(act);

        return row;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12.5f);
        t.setTextColor(cSub());
        t.setPadding(0, dp(4), 0, dp(6));
        return t;
    }

    private View chipRows(String[] names, boolean isSrc) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        for (int r = 0; r < 2; r++) {
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = r * 3; i < Math.min(names.length, r * 3 + 3); i++) {
                final String name = names[i];
                final boolean src = isSrc;
                TextView chip = new TextView(this);
                chip.setText(name);
                chip.setTextSize(11.5f);
                chip.setGravity(Gravity.CENTER);
                chip.setPadding(dp(14), dp(9), dp(14), dp(9));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.rightMargin = dp(8);
                chip.setLayoutParams(lp);
                chip.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (src) srcVendor = name;
                        else dstVendor = name;
                        paintChips();
                    }
                });
                row.addView(chip);
                if (src) srcChips.add(chip);
                else dstChips.add(chip);
            }
            hs.addView(row);
            LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            hlp.topMargin = dp(4);
            hs.setLayoutParams(hlp);
            col.addView(hs);
        }
        return col;
    }

    private void paintChips() {
        for (TextView t : srcChips) {
            boolean on = t.getText().toString().equals(srcVendor);
            t.setBackground(on ? round(cAccent(), 20) : round(cSoft(), 20));
            t.setTextColor(on ? 0xFFFFFFFF : cText());
        }
        for (TextView t : dstChips) {
            boolean on = t.getText().toString().equals(dstVendor);
            t.setBackground(on ? round(cAccent(), 20) : round(cSoft(), 20));
            t.setTextColor(on ? 0xFFFFFFFF : cText());
        }
    }

    // ---------------- 转换 ----------------
    private void convert() {
        final String text = input.getText().toString();
        if (text.trim().length() == 0) {
            Toast.makeText(this, "先粘贴源设备配置", Toast.LENGTH_SHORT).show();
            return;
        }
        convertBtn.setEnabled(false);
        convertBtn.setText("转换中…");

        final String src = srcVendor;
        final String dst = dstVendor;

        new Thread(new Runnable() {
            @Override
            public void run() {
                String out = null;
                String err = null;
                final Model m = new Model();
                m.srcVendor = src;
                m.dstVendor = dst;
                m.paSet = paSetFormat();
                try {
                    Parsers.parse(src, text, m);
                    if (m.addrs.isEmpty() && m.pols.isEmpty()
                            && m.svcs.isEmpty() && m.dnats.isEmpty() && m.snats.isEmpty()) {
                        err = "没有解析到任何对象，请确认源厂商选择是否对应";
                    } else {
                        out = Emit.build(m);
                    }
                } catch (Throwable t) {
                    err = "解析出错：" + (t.getMessage() == null ? t.getClass().getSimpleName()
                            : t.getMessage());
                }

                final String fErr = err;
                final String[] fSec = err == null ? Emit.sections(m) : null;
                final Model fm = m;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        convertBtn.setEnabled(true);
                        convertBtn.setText("开始转换");
                        if (fErr != null) {
                            Toast.makeText(MainActivity.this, fErr, Toast.LENGTH_LONG).show();
                            return;
                        }
                        renderSections(fm, fSec);
                        showNotes(fm.notes);
                        Toast.makeText(MainActivity.this,
                                "已转换：" + fm.addrs.size() + " 个地址 · " + fm.svcs.size()
                                        + " 个服务 · " + fm.pols.size() + " 条策略 · "
                                        + (fm.dnats.size() + fm.snats.size()) + " 条 NAT",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).start();
    }

    /** 分四段展示：地址 / 服务 / 策略 / NAT */
    private void renderSections(Model m, String[] secs) {
        secModel = m;
        secCache = secs == null ? new String[4] : secs;
        resultBox.removeAllViews();

        StringBuilder all = new StringBuilder();
        all.append("# ").append(m.srcVendor).append(" → ").append(m.dstVendor).append("\n\n");
        for (int i = 0; i < 4; i++) {
            String body = secCache[i] == null ? "" : secCache[i].trim();
            if (body.length() > 0) {
                all.append("# ").append(secNames[i]).append("\n").append(body).append("\n\n");
            }
        }
        resultAll = all.toString().trim() + "\n";

        // 顶部分段切换
        secTabs = new LinearLayout(this);
        secTabs.setOrientation(LinearLayout.HORIZONTAL);
        secTabs.setBackground(round(cSoft(), 14));
        secTabs.setPadding(dp(3), dp(3), dp(3), dp(3));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        secTabs.setLayoutParams(tlp);

        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView tab = new TextView(this);
            String body = secCache[i] == null ? "" : secCache[i].trim();
            tab.setText(body.length() > 0 ? secNames[i] : secNames[i] + "·无");
            tab.setTextSize(11.5f);
            tab.setGravity(Gravity.CENTER);
            tab.setPadding(0, dp(8), 0, dp(8));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tab.setLayoutParams(clp);
            tab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    paintTab(idx);
                }
            });
            secTabs.addView(tab);
        }
        resultBox.addView(secTabs);

        // 内容卡片
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(round(cCard(), 14));
        card.setPadding(dp(12), dp(10), dp(12), dp(12));
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        klp.topMargin = dp(8);
        card.setLayoutParams(klp);

        LinearLayout head2 = new LinearLayout(this);
        head2.setOrientation(LinearLayout.HORIZONTAL);
        head2.setGravity(Gravity.CENTER_VERTICAL);

        secCount = new TextView(this);
        secCount.setTextSize(10.5f);
        secCount.setTextColor(cSub());
        secCount.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head2.addView(secCount);

        secCopy = new TextView(this);
        secCopy.setText("复制本段");
        secCopy.setTextSize(11.5f);
        secCopy.setTextColor(cAccent());
        secCopy.setPadding(dp(10), dp(4), dp(2), dp(4));
        secCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = secCache[secIndex] == null ? "" : secCache[secIndex].trim();
                if (t.length() == 0) {
                    Toast.makeText(MainActivity.this, "这一段没有内容", Toast.LENGTH_SHORT).show();
                    return;
                }
                copyText(t, secNames[secIndex]);
            }
        });
        head2.addView(secCopy);
        card.addView(head2);

        secBody = new TextView(this);
        secBody.setTextSize(10.5f);
        secBody.setTypeface(Typeface.MONOSPACE);
        secBody.setTextIsSelectable(true);
        secBody.setPadding(0, dp(7), 0, 0);
        card.addView(secBody);

        resultBox.addView(card);
        resultBox.setVisibility(View.VISIBLE);
        paintTab(0);
    }

    /** 切换分段并刷新内容区 */
    private void paintTab(int idx) {
        secIndex = idx;
        if (secTabs == null) return;
        for (int i = 0; i < secTabs.getChildCount(); i++) {
            TextView t = (TextView) secTabs.getChildAt(i);
            boolean on = i == idx;
            String body = secCache[i] == null ? "" : secCache[i].trim();
            t.setBackground(on ? round(cAccent(), 11) : null);
            t.setTextColor(on ? 0xFFFFFFFF : (body.length() > 0 ? cText() : cSub()));
            t.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
        String body = secCache[idx] == null ? "" : secCache[idx].trim();
        if (secCount != null) {
            String n = emptyHint(secModel, idx);
            secCount.setText(n.length() > 0 ? n : "无");
        }
        if (secBody != null) {
            secBody.setText(body.length() > 0 ? body : "（源配置中没有这类对象）");
            secBody.setTextColor(body.length() > 0 ? cText() : cSub());
        }
        if (secCopy != null) secCopy.setVisibility(body.length() > 0 ? View.VISIBLE : View.GONE);
    }

    private String emptyHint(Model m, int i) {
        int n;
        switch (i) {
            case 0: n = m.addrs.size(); break;
            case 1: n = m.svcs.size(); break;
            case 2: n = m.pols.size(); break;
            default: n = m.dnats.size() + m.snats.size(); break;
        }
        if (i == 3) {
            return n > 0 ? "目的 " + m.dnats.size() + " 条 · 源 " + m.snats.size() + " 条" : "";
        }
        return n > 0 ? n + (i == 2 ? " 条规则" : " 个对象") : "";
    }

    private void copyText(String text, String label) {
        android.content.ClipboardManager cm = (android.content.ClipboardManager)
                getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("firewall-config", text));
        Toast.makeText(this, "已复制「" + label + "」到剪贴板", Toast.LENGTH_SHORT).show();
    }

    private void showNotes(List<String> notes) {
        noteBox.removeAllViews();
        if (notes.isEmpty()) {
            noteTitle.setVisibility(View.GONE);
            noteBox.setVisibility(View.GONE);
            return;
        }
        noteTitle.setVisibility(View.VISIBLE);
        noteBox.setVisibility(View.VISIBLE);
        for (String n : notes) {
            TextView t = new TextView(this);
            t.setText("• " + n);
            t.setTextSize(11.5f);
            t.setTextColor(dark ? 0xFFE0C083 : 0xFF8A6209);
            t.setPadding(0, dp(3), 0, dp(3));
            noteBox.addView(t);
        }
    }

    private void copyResult() {
        if (TextUtils.isEmpty(resultAll)) {
            Toast.makeText(this, "还没有转换结果", Toast.LENGTH_SHORT).show();
            return;
        }
        copyText(resultAll, "全部");
    }

    private void shareResult() {
        String s = resultAll;
        if (TextUtils.isEmpty(s)) {
            Toast.makeText(this, "还没有转换结果", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent it = new Intent(Intent.ACTION_SEND);
        it.setType("text/plain");
        it.putExtra(Intent.EXTRA_SUBJECT, srcVendor + " → " + dstVendor + " 配置");
        it.putExtra(Intent.EXTRA_TEXT, s);
        startActivity(Intent.createChooser(it, "分享配置"));
    }
}
