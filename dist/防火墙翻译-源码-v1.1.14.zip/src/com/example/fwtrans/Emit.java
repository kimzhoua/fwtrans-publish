package com.example.fwtrans;

import java.util.List;
/** 生成目标厂商配置 */
final class Emit {

    static final int P_ALL = 0, P_ADDR = 1, P_SVC = 2, P_POL = 3, P_NAT = 4;
    private static int part = P_ALL;

    private static boolean w(int p) {
        return part == P_ALL || part == p;
    }

    /** 按 地址 / 服务 / 策略 / NAT 四段分别生成 */
    static String[] sections(Model m) {
        String[] out = new String[4];
        boolean[] has = new boolean[]{!m.addrs.isEmpty(), !m.svcs.isEmpty(),
                !m.pols.isEmpty(), !(m.dnats.isEmpty() && m.snats.isEmpty())};
        for (int i = 0; i < 4; i++) {
            if (!has[i]) {
                out[i] = "";
                continue;
            }
            part = P_ADDR + i;
            String t = build(m);
            out[i] = t == null ? "" : t.trim();
        }
        part = P_ALL;
        return out;
    }

    static String build(Model m) {
        switch (m.dstVendor) {
            case "华为 USG":
                return huawei(m);
            case "华三 H3C":
                return h3c(m);
            case "飞塔 Fortinet":
                return forti(m);
            case "山石 Hillstone":
                return hillstone(m);
            case "Palo Alto":
                return pa(m);
            case "Cisco ASA":
                return asa(m);
            default:
                return "# 未知目标厂商";
        }
    }

    private static String head(Model m, String syntax) {
        if (part != P_ALL) return "";
        boolean noZone = false;
        for (Model.Pol p : m.pols) {
            if (p.from == null || p.from.length() == 0) {
                noZone = true;
                break;
            }
        }
        if (noZone) {
            m.note("源配置没有区域/接口信息，目标侧的策略区域用了占位名，请按实际 zone 或接口调整");
        }
        return "# 由「防火墙翻译」生成：" + m.srcVendor + " → " + m.dstVendor + "\n"
                + "# 目标语法参考：" + syntax + "\n"
                + "# 区域/接口名沿用源配置，导入前请核对对应关系\n\n";
    }

    private static String q(String s) {
        return "\"" + s + "\"";
    }

    private static String[] ports(String port) {
        if (port == null || port.length() == 0) return new String[]{"", ""};
        if (port.contains("-")) {
            String[] p = port.split("-");
            return new String[]{p[0], p.length > 1 ? p[1] : p[0]};
        }
        return new String[]{port, port};
    }

    private static boolean any(List<String> l) {
        return l.isEmpty() || (l.size() == 1 && "any".equalsIgnoreCase(l.get(0)));
    }

    // ---------------- 华为 ----------------
    private static String huawei(Model m) {
        StringBuilder sb = new StringBuilder(head(m, "华为 USG6000 / USG 系列"));

if (w(P_ADDR)) {
        for (Model.AddrUnit u : Model.addrUnits(m)) {
            sb.append("ip address-set ").append(u.name).append(" type object\n");
            int midx = 0;
            for (Model.Addr a : u.members) {
                if ("fqdn".equals(a.type)) {
                    m.note("华为地址对象不支持域名 " + a.name + "，请用 IP 或 DNS 策略替代");
                    continue;
                }
                sb.append(" address ").append(midx);
                if ("range".equals(a.type)) {
                    sb.append(" ").append(a.ip).append(" ").append(a.ip2).append("\n");
                } else {
                    sb.append(" ").append(a.ip).append(" mask ")
                            .append(Model.prefixToMask(a.prefix)).append("\n");
                }
                midx++;
            }
            sb.append("\n");
        }
}

if (w(P_SVC)) {
        for (Model.Svc s : m.svcs) {
            if ("icmp".equals(s.proto)) {
                sb.append("# 服务 ").append(s.name).append("：ICMP，用 service icmp 引用\n\n");
                continue;
            }
            String[] p = ports(s.port);
            if (p[0].length() == 0) continue;
            sb.append("ip service-set ").append(s.name).append(" type object\n");
            sb.append(" service 0 ").append(s.proto).append(" ").append(p[0])
                    .append(" ").append(p[1]).append("\n\n");
        }
}

        if (w(P_POL)) sb.append("security-policy\n");
if (w(P_POL)) {
        for (Model.Pol p : m.pols) {
            sb.append(" rule name ").append(p.name).append("\n");
            if (p.from.length() > 0) sb.append("  source-zone ").append(p.from).append("\n");
            if (p.to.length() > 0) sb.append("  destination-zone ").append(p.to).append("\n");
            if (!any(p.src)) {
                for (String n : p.src) {
                    sb.append("  source-address ").append(ref(m, n)).append("\n");
                }
            }
            if (!any(p.dst)) {
                for (String n : p.dst) {
                    sb.append("  destination-address ").append(ref(m, n)).append("\n");
                }
            }
            if (!any(p.svc)) {
                for (String n : p.svc) {
                    if ("icmp".equals(svcProto(m, n))) sb.append("  service icmp\n");
                    else sb.append("  service ").append(n).append("\n");
                }
            }
            sb.append("  action ").append(p.isDeny() ? "deny" : "permit").append("\n\n");
        }
}

if (w(P_NAT)) {
        for (Model.Dnat d : m.dnats) {
            sb.append("# 目的NAT（服务器映射）\n");
            sb.append("nat static global ").append(d.extIp)
                    .append(" inside ").append(d.intIp).append("\n\n");
        }
}
if (w(P_NAT)) {
        for (Model.Snat s : m.snats) {
            sb.append("# 源NAT：策略 ").append(s.name).append(" 需在接口上配 nat outbound，")
                    .append("并把源地址翻译为 ").append(s.toIp).append("\n");
        }
}
        return sb.toString();
    }

    private static String ref(Model m, String name) {
        if (Model.isIp(name)) return m.ensureAddr(name, 32);
        return name;
    }

    private static String svcProto(Model m, String name) {
        Model.Svc s = m.svc(name);
        return s == null ? "" : s.proto;
    }

    // ---------------- 华三 ----------------
    private static String h3c(Model m) {
        StringBuilder sb = new StringBuilder(head(m, "H3C Comware V7 防火墙"));

if (w(P_ADDR)) {
        for (Model.AddrUnit u : Model.addrUnits(m)) {
            sb.append("object-group ip address ").append(u.name).append("\n");
            int midx = 0;
            for (Model.Addr a : u.members) {
                if ("fqdn".equals(a.type)) {
                    m.note("华三地址对象不支持域名 " + a.name);
                    continue;
                }
                sb.append(" ").append(midx).append(" ");
                if ("range".equals(a.type)) {
                    sb.append("network-range ").append(a.ip).append(" ").append(a.ip2);
                } else if (a.prefix == 32) {
                    sb.append("network host address ").append(a.ip);
                } else {
                    sb.append("network-subnet ").append(a.ip).append(" ")
                            .append(Model.prefixToMask(a.prefix));
                }
                sb.append("\n");
                midx += 10;
            }
            sb.append("\n");
        }
}

if (w(P_SVC)) {
        for (Model.Svc s : m.svcs) {
            if ("icmp".equals(s.proto)) continue;
            String[] p = ports(s.port);
            if (p[0].length() == 0) continue;
            sb.append("object-group service ").append(s.name).append("\n");
            if (p[0].equals(p[1])) {
                sb.append(" service ").append(s.proto).append(" destination eq ").append(p[0]).append("\n\n");
            } else {
                sb.append(" service ").append(s.proto).append(" destination range ").append(p[0])
                        .append(" ").append(p[1]).append("\n\n");
            }
        }
}

        if (w(P_POL)) sb.append("security-policy ip\n");
if (w(P_POL)) {
        for (Model.Pol p : m.pols) {
            sb.append(" rule name ").append(p.name).append("\n");
            if (p.from.length() > 0) sb.append("  source-zone ").append(p.from).append("\n");
            if (p.to.length() > 0) sb.append("  destination-zone ").append(p.to).append("\n");
            if (!any(p.src)) {
                for (String n : p.src) sb.append("  source-ip ").append(ref(m, n)).append("\n");
            }
            if (!any(p.dst)) {
                for (String n : p.dst) sb.append("  destination-ip ").append(ref(m, n)).append("\n");
            }
            if (!any(p.svc)) {
                for (String n : p.svc) if (!"icmp".equals(svcProto(m, n)))
                    sb.append("  service ").append(n).append("\n");
            }
            sb.append("  action ").append(p.isDeny() ? "drop" : "pass").append("\n\n");
        }
}

if (w(P_NAT)) {
        for (Model.Dnat d : m.dnats) {
            sb.append("# 目的NAT（nat server）\n");
            sb.append("nat server protocol ").append(d.proto)
                    .append(" global ").append(d.extIp);
            if (d.extPort != null && d.extPort.length() > 0) sb.append(" ").append(d.extPort);
            sb.append(" inside ").append(d.intIp);
            if (d.intPort != null && d.intPort.length() > 0) sb.append(" ").append(d.intPort);
            sb.append("\n\n");
        }
}
if (w(P_NAT)) {
        for (Model.Snat s : m.snats) {
            sb.append("# 源NAT：nat outbound 需绑定 ACL，翻译地址 ").append(s.toIp).append("\n");
        }
}
        return sb.toString();
    }

    /** 同一组多成员在目标平台无组语法时，成员名加序号避免重名 */
    private static String uniqAddr(Model m, Model.Addr a, java.util.Map<String, Integer> seen) {
        Integer c = seen.get(a.name);
        if (c == null) {
            seen.put(a.name, 0);
            return a.name;
        }
        int k = c + 1;
        seen.put(a.name, k);
        m.note("目标平台没有同名多成员组语法，" + a.name + " 第 " + (k + 1) + " 个成员改用 " + a.name + "_" + k);
        return a.name + "_" + k;
    }

    // ---------------- 飞塔 ----------------
    private static String forti(Model m) {
        StringBuilder sb = new StringBuilder(head(m, "FortiOS 6.x / 7.x"));

        if (w(P_ADDR)) sb.append("config firewall address\n");
if (w(P_ADDR)) {
        java.util.Map<String, Integer> seen = new java.util.HashMap<>();
        for (Model.Addr a0 : m.addrs) {
            Model.Addr a = a0;
            String anm = uniqAddr(m, a, seen);
            sb.append("    edit ").append(q(anm)).append("\n");
            if ("fqdn".equals(a.type)) {
                sb.append("        set type fqdn\n");
                sb.append("        set fqdn ").append(q(a.fqdn)).append("\n");
            } else if ("range".equals(a.type)) {
                sb.append("        set type iprange\n");
                sb.append("        set start-ip ").append(a.ip).append("\n");
                sb.append("        set end-ip ").append(a.ip2).append("\n");
            } else {
                sb.append("        set subnet ").append(a.ip).append(" ")
                        .append(Model.prefixToMask(a.prefix)).append("\n");
            }
            sb.append("    next\n");
        }
}
        if (w(P_ADDR)) sb.append("end\n\n");

        if (w(P_SVC)) sb.append("config firewall service custom\n");
if (w(P_SVC)) {
        for (Model.Svc s : m.svcs) {
            String[] p = ports(s.port);
            if ("icmp".equals(s.proto)) continue;
            if (p[0].length() == 0) continue;
            sb.append("    edit ").append(q(s.name)).append("\n");
            sb.append("        set ").append(s.proto).append("-portrange ")
                    .append(q(p[0].equals(p[1]) ? p[0] : p[0] + "-" + p[1])).append("\n");
            sb.append("    next\n");
        }
}
        if (w(P_SVC)) sb.append("end\n\n");

        if (w(P_POL)) sb.append("config firewall policy\n");
        if (w(P_POL)) {
int idx = 1;
        for (Model.Pol p : m.pols) {
            sb.append("    edit ").append(idx++).append("\n");
            sb.append("        set name ").append(q(p.name)).append("\n");
            sb.append("        set srcintf ").append(q(p.from.length() > 0 ? p.from : "any")).append("\n");
            sb.append("        set dstintf ").append(q(p.to.length() > 0 ? p.to : "any")).append("\n");
            sb.append("        set srcaddr ").append(joinAddr(p.src)).append("\n");
            sb.append("        set dstaddr ").append(joinAddr(p.dst)).append("\n");
            sb.append("        set service ").append(joinSvc(m, p.svc)).append("\n");
            sb.append("        set action ").append(p.isDeny() ? "deny" : "accept").append("\n");
            sb.append("    next\n");
        }
}
        if (w(P_POL)) sb.append("end\n\n");

if (w(P_NAT)) {
        for (Model.Dnat d : m.dnats) {
            sb.append("config firewall vip\n");
            sb.append("    edit ").append(q(d.name)).append("\n");
            sb.append("        set extip ").append(d.extIp).append("\n");
            sb.append("        set mappedip ").append(q(d.intIp)).append("\n");
            if (d.extPort != null && d.extPort.length() > 0)
                sb.append("        set extport ").append(d.extPort).append("\n");
            if (d.intPort != null && d.intPort.length() > 0)
                sb.append("        set mappedport ").append(d.intPort).append("\n");
            sb.append("        set protocol ").append(d.proto).append("\n");
            sb.append("    next\n");
            if (w(P_NAT)) sb.append("end\n\n");
        }
}

if (w(P_NAT)) {
        for (Model.Snat s : m.snats) {
            sb.append("# 源NAT：策略需 set nat enable，并使用 IP 池 ").append(s.toIp).append("\n");
        }
}
        return sb.toString();
    }

    private static String joinAddr(List<String> l) {
        if (any(l)) return q("all");
        StringBuilder sb = new StringBuilder();
        for (String n : l) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(q(n));
        }
        return sb.toString();
    }

    private static String joinSvc(Model m, List<String> l) {
        if (any(l)) return q("ALL");
        StringBuilder sb = new StringBuilder();
        for (String n : l) {
            String v = "icmp".equals(svcProto(m, n)) ? "ALL_ICMP" : n;
            if (sb.length() > 0) sb.append(" ");
            sb.append(q(v));
        }
        return sb.toString();
    }

    // ---------------- 山石 ----------------
    private static String hillstone(Model m) {
        StringBuilder sb = new StringBuilder(head(m, "Hillstone StoneOS 5.x"));

if (w(P_ADDR)) {
        java.util.Map<String, Integer> seen = new java.util.HashMap<>();
        for (Model.Addr a0 : m.addrs) {
            Model.Addr a = a0;
            String anm = uniqAddr(m, a, seen);
            if ("fqdn".equals(a.type)) {
                sb.append("address ").append(q(anm)).append(" ").append(a.fqdn).append("\n");
            } else if ("range".equals(a.type)) {
                sb.append("address ").append(q(anm)).append(" ").append(a.ip)
                        .append(" ").append(a.ip2).append("\n");
            } else {
                sb.append("address ").append(q(anm)).append(" ").append(a.ip)
                        .append("/").append(a.prefix).append("\n");
            }
        }
}
        if (w(P_ADDR)) if (w(P_SVC)) if (w(P_POL)) sb.append("\n");

if (w(P_SVC)) {
        for (Model.Svc s : m.svcs) {
            String[] p = ports(s.port);
            if ("icmp".equals(s.proto)) {
                sb.append("service ").append(q(s.name)).append(" icmp\n");
                continue;
            }
            if (p[0].length() == 0) continue;
            sb.append("service ").append(q(s.name)).append(" ").append(s.proto)
                    .append(" ").append(p[0]).append(" ").append(p[1]).append("\n");
        }
}
        sb.append("\n");

        if (w(P_POL)) sb.append("policy\n");
        if (w(P_POL)) {
int id = 1;
        for (Model.Pol p : m.pols) {
            sb.append("  rule id ").append(id++).append("\n");
            sb.append("    name ").append(q(p.name)).append("\n");
            if (p.from.length() > 0 || p.to.length() > 0) {
                sb.append("    from ").append(q(p.from.length() > 0 ? p.from : "any"))
                        .append(" to ").append(q(p.to.length() > 0 ? p.to : "any")).append("\n");
            }
            sb.append("    match src-ip ")
                    .append(any(p.src) ? q("any") : q(p.src.get(0)))
                    .append(" dst-ip ")
                    .append(any(p.dst) ? q("any") : q(p.dst.get(0)));
            sb.append(" service ").append(any(p.svc) ? q("any") : q(p.svc.get(0))).append("\n");
            if (p.src.size() > 1 || p.dst.size() > 1 || p.svc.size() > 1)
                m.note("山石规则 " + p.name + " 有多地址/服务，已取第一个，需手工补充");
            sb.append("    action ").append(p.isDeny() ? "deny" : "permit").append("\n");
        }
}
        sb.append("\n");

if (w(P_NAT)) {
        for (Model.Dnat d : m.dnats) {
            sb.append("# 目的NAT：").append(d.proto).append(" ").append(d.extIp)
                    .append(d.extPort == null || d.extPort.length() == 0 ? "" : ":" + d.extPort)
                    .append(" → ").append(d.intIp).append(":").append(d.intPort)
                    .append("（山石需在 NAT 策略中配置 VIP 映射）\n");
        }
}
if (w(P_NAT)) {
        for (Model.Snat s : m.snats) {
            sb.append("nat\n  rule id ").append(m.snats.indexOf(s) + 1).append("\n");
            sb.append("    match src-ip ").append(q(s.src)).append("\n");
            sb.append("    translate src-ip ").append(q(s.toIp)).append("\n");
        }
}
        return sb.toString();
    }

    // ---------------- Palo Alto ----------------
    private static String pa(Model m) {
        if (!m.paSet) return paXml(m);
        StringBuilder sb = new StringBuilder(head(m, "Palo Alto PAN-OS（set 命令）"));

        if (w(P_ADDR)) {
            java.util.Map<String, Integer> seen = new java.util.HashMap<>();
            for (Model.Addr a : m.addrs) {
                String anm = uniqAddr(m, a, seen);
                sb.append("set address ").append(xq(anm));
                if ("fqdn".equals(a.type)) {
                    sb.append(" fqdn ").append(a.fqdn);
                } else if ("range".equals(a.type)) {
                    sb.append(" ip-range ").append(a.ip).append("-").append(a.ip2);
                } else {
                    sb.append(" ip-netmask ").append(a.ip).append("/").append(a.prefix);
                }
                sb.append("\n");
            }
            if (!m.addrs.isEmpty()) sb.append("\n");
        }

        if (w(P_SVC)) {
            for (Model.Svc s : m.svcs) {
                String[] p = ports(s.port);
                if ("icmp".equals(s.proto)) continue;
                if (p[0].length() == 0) continue;
                sb.append("set service ").append(xq(s.name)).append(" protocol ")
                        .append(s.proto).append(" port ")
                        .append(p[0].equals(p[1]) ? p[0] : p[0] + "-" + p[1]).append("\n");
            }
            if (!m.svcs.isEmpty()) sb.append("\n");
        }

        if (w(P_POL)) {
            for (Model.Pol p : m.pols) {
                String base = "set rulebase security rules " + xq(p.name);
                if (p.from.length() > 0) sb.append(base).append(" from ").append(xq(p.from)).append("\n");
                if (p.to.length() > 0) sb.append(base).append(" to ").append(xq(p.to)).append("\n");
                sb.append(base).append(" source ").append(listArg(p.src)).append("\n");
                sb.append(base).append(" destination ").append(listArg(p.dst)).append("\n");
                sb.append(base).append(" service ").append(listArg(p.svc)).append("\n");
                sb.append(base).append(" action ").append(p.isDeny() ? "deny" : "allow").append("\n\n");
            }
        }

        if (w(P_NAT)) {
            int n = 1;
            for (Model.Dnat d : m.dnats) {
                String base = "set rulebase nat rules " + xq("dnat_" + n++);
                String svcName = null;
                if (d.extPort != null && d.extPort.length() > 0) {
                    svcName = d.name + "_ext";
                    sb.append("set service ").append(xq(svcName)).append(" protocol ")
                            .append(d.proto).append(" port ").append(d.extPort).append("\n");
                }
                sb.append(base).append(" from ").append(xq("any")).append("\n");
                sb.append(base).append(" to ").append(xq("any")).append("\n");
                sb.append(base).append(" source ").append(xq("any")).append("\n");
                sb.append(base).append(" destination ").append(xq(d.extIp)).append("\n");
                sb.append(base).append(" service ").append(xq(svcName == null ? "any" : svcName)).append("\n");
                sb.append(base).append(" destination-translation translated-address ")
                        .append(xq(d.intIp)).append("\n");
                if (d.intPort != null && d.intPort.length() > 0 && !d.intPort.equals(d.extPort)) {
                    sb.append(base).append(" destination-translation translated-port ")
                            .append(d.intPort).append("\n");
                }
                sb.append("\n");
            }
            for (Model.Snat sn : m.snats) {
                String base = "set rulebase nat rules " + xq(sn.name);
                sb.append(base).append(" source ").append(xq(sn.src)).append("\n");
                sb.append(base).append(" destination ").append(xq(sn.dst)).append("\n");
                sb.append(base).append(" service ").append(xq(sn.svc)).append("\n");
                sb.append(base).append(" source-translation dynamic-ip-and-port translated-address ")
                        .append(xq(sn.toIp)).append("\n\n");
            }
            if (!m.dnats.isEmpty() || !m.snats.isEmpty()) {
                m.note("PA 的策略与 NAT 需要 from/to 区域，已用 any 占位，导入前请按实际 zone 调整");
            }
        }
        return sb.toString();
    }

    /** PA 的 XML 版本（可导入 device state / 参考配置） */
    private static String paXml(Model m) {
        StringBuilder sb = new StringBuilder();
        if (part == P_ALL) {
            sb.append("<!-- 由「防火墙翻译」生成：").append(m.srcVendor)
                    .append(" → Palo Alto PAN-OS（XML） -->\n");
            sb.append("<config>\n  <devices>\n    <entry name=\"localhost.localdomain\">\n");
            sb.append("      <vsys>\n        <entry name=\"vsys1\">\n");
        }

        if (w(P_ADDR) && !m.addrs.isEmpty()) {
            sb.append("          <address>\n");
            java.util.Map<String, Integer> seen = new java.util.HashMap<>();
            for (Model.Addr a : m.addrs) {
                String anm = uniqAddr(m, a, seen);
                sb.append("            <entry name=").append(xq(anm)).append(">\n");
                if ("fqdn".equals(a.type)) {
                    sb.append("              <fqdn>").append(a.fqdn).append("</fqdn>\n");
                } else if ("range".equals(a.type)) {
                    sb.append("              <ip-range>").append(a.ip).append("-").append(a.ip2)
                            .append("</ip-range>\n");
                } else {
                    sb.append("              <ip-netmask>").append(a.ip).append("/")
                            .append(a.prefix).append("</ip-netmask>\n");
                }
                sb.append("            </entry>\n");
            }
            sb.append("          </address>\n");
        }

        if (w(P_SVC) && !m.svcs.isEmpty()) {
            sb.append("          <service>\n");
            for (Model.Svc s : m.svcs) {
                String[] p = ports(s.port);
                if ("icmp".equals(s.proto) || p[0].length() == 0) continue;
                sb.append("            <entry name=").append(xq(s.name)).append(">\n");
                sb.append("              <protocol>\n                <").append(s.proto).append(">\n");
                sb.append("                  <port>").append(p[0].equals(p[1]) ? p[0] : p[0] + "-" + p[1])
                        .append("</port>\n");
                sb.append("                </").append(s.proto).append(">\n              </protocol>\n");
                sb.append("            </entry>\n");
            }
            sb.append("          </service>\n");
        }

        if (w(P_POL) && !m.pols.isEmpty()) {
            sb.append("          <rulebase>\n            <security>\n              <rules>\n");
            for (Model.Pol p : m.pols) {
                sb.append("                <entry name=").append(xq(p.name)).append(">\n");
                sb.append("                  <from><member>")
                        .append(p.from.length() > 0 ? p.from : "any").append("</member></from>\n");
                sb.append("                  <to><member>")
                        .append(p.to.length() > 0 ? p.to : "any").append("</member></to>\n");
                sb.append("                  <source>").append(members(p.src)).append("</source>\n");
                sb.append("                  <destination>").append(members(p.dst)).append("</destination>\n");
                sb.append("                  <service>").append(members(p.svc)).append("</service>\n");
                sb.append("                  <action>").append(p.isDeny() ? "deny" : "allow")
                        .append("</action>\n");
                sb.append("                </entry>\n");
            }
            sb.append("              </rules>\n            </security>\n          </rulebase>\n");
        }

        if (w(P_NAT) && (!m.dnats.isEmpty() || !m.snats.isEmpty())) {
            sb.append("          <nat>\n            <rules>\n");
            int n = 1;
            for (Model.Dnat d : m.dnats) {
                sb.append("              <entry name=").append(xq("dnat_" + n++)).append(">\n");
                sb.append("                <destination-translation>\n");
                sb.append("                  <translated-address><member>").append(d.intIp)
                        .append("</member></translated-address>\n");
                if (d.intPort != null && d.intPort.length() > 0)
                    sb.append("                  <translated-port>").append(d.intPort)
                            .append("</translated-port>\n");
                sb.append("                </destination-translation>\n");
                sb.append("              </entry>\n");
            }
            n = 1;
            for (Model.Snat sn : m.snats) {
                sb.append("              <entry name=").append(xq("snat_" + n++)).append(">\n");
                sb.append("                <source-translation>\n");
                sb.append("                  <dynamic-ip-and-port>\n");
                sb.append("                    <translated-address><member>").append(sn.toIp)
                        .append("</member></translated-address>\n");
                sb.append("                  </dynamic-ip-and-port>\n");
                sb.append("                </source-translation>\n");
                sb.append("              </entry>\n");
            }
            sb.append("            </rules>\n          </nat>\n");
        }

        if (part == P_ALL) {
            sb.append("        </entry>\n      </vsys>\n    </entry>\n  </devices>\n</config>\n");
        }
        return sb.toString();
    }

    /** 单值直接给，多值给 [ "a" "b" ] 列表，空给 any */
    private static String listArg(List<String> l) {
        if (any(l)) return xq("any");
        if (l.size() == 1) return xq(l.get(0));
        StringBuilder sb = new StringBuilder("[");
        for (String n : l) sb.append(" ").append(xq(n));
        return sb.append(" ]").toString();
    }

    private static String xq(String s) {
        return "\"" + s + "\"";
    }

    private static String members(List<String> l) {
        if (any(l)) return "<member>any</member>";
        StringBuilder sb = new StringBuilder();
        for (String n : l) sb.append("<member>").append(n).append("</member>");
        return sb.toString();
    }

    // ---------------- Cisco ASA ----------------
    private static String asa(Model m) {
        StringBuilder sb = new StringBuilder(head(m, "Cisco ASA 9.x"));

if (w(P_ADDR)) {
        java.util.Map<String, Integer> seen = new java.util.HashMap<>();
        for (Model.Addr a0 : m.addrs) {
            Model.Addr a = a0;
            String anm = uniqAddr(m, a, seen);
            sb.append("object network ").append(anm).append("\n");
            if ("fqdn".equals(a.type)) {
                sb.append(" fqdn ").append(a.fqdn).append("\n");
            } else if ("range".equals(a.type)) {
                sb.append(" range ").append(a.ip).append(" ").append(a.ip2).append("\n");
            } else if (a.prefix == 32) {
                sb.append(" host ").append(a.ip).append("\n");
            } else {
                sb.append(" subnet ").append(a.ip).append(" ").append(Model.prefixToMask(a.prefix))
                        .append("\n");
            }
            sb.append("\n");
        }
}

if (w(P_SVC)) {
        for (Model.Svc s : m.svcs) {
            if ("icmp".equals(s.proto)) continue;
            String[] p = ports(s.port);
            if (p[0].length() == 0) continue;
            sb.append("object service ").append(s.name).append("\n");
            if (p[0].equals(p[1])) {
                sb.append(" service ").append(s.proto).append(" destination eq ").append(p[0]).append("\n");
            } else {
                sb.append(" service ").append(s.proto).append(" destination range ").append(p[0])
                        .append(" ").append(p[1]).append("\n");
            }
            sb.append("\n");
        }
}

        if (w(P_POL)) {
int aclSeq = 0;
        for (Model.Pol p : m.pols) {
            String acl = p.from.length() > 0 ? p.from : "OUTSIDE_IN";
            String proto = "ip";
            if (!any(p.svc)) {
                String sp = svcProto(m, p.svc.get(0));
                if ("tcp".equals(sp) || "udp".equals(sp)) proto = sp;
                else if ("icmp".equals(sp)) proto = "icmp";
            }
            for (String s : p.svc) {
                if (++aclSeq > 0 && p.svc.size() > 1) break;
            }
            sb.append("access-list ").append(acl).append(" extended ")
                    .append(p.isDeny() ? "deny" : "permit").append(" ").append(proto).append(" ");
            sb.append(any(p.src) ? "any" : "object " + p.src.get(0)).append(" ");
            sb.append(any(p.dst) ? "any" : "object " + p.dst.get(0)).append(" ");
            if (!any(p.svc)) {
                Model.Svc s = m.svc(p.svc.get(0));
                if (s != null && "tcp".equals(s.proto) || s != null && "udp".equals(s.proto)) {
                    if (s.port != null && s.port.contains("-")) {
                        String[] pr = ports(s.port);
                        sb.append("range ").append(pr[0]).append(" ").append(pr[1]);
                    } else if (s.port != null && s.port.length() > 0) {
                        sb.append("eq ").append(s.port);
                    } else {
                        sb.append("object ").append(s.name);
                    }
                } else {
                    sb.append("object ").append(p.svc.get(0));
                }
            }
            sb.append("\n");
            if (p.src.size() > 1 || p.dst.size() > 1)
                m.note("ASA ACL 每条只能写一源一目的，规则 " + p.name + " 已取第一个地址");
        }
}
        sb.append("\n");

if (w(P_NAT)) {
        for (Model.Dnat d : m.dnats) {
            sb.append("object network dnat_").append(d.intIp.replace('.', '_')).append("\n");
            sb.append(" host ").append(d.intIp).append("\n");
            sb.append(" nat (outside,inside) static ").append(d.extIp).append("\n\n");
        }
}
if (w(P_NAT)) {
        for (Model.Snat s : m.snats) {
            sb.append("object network ").append(s.name).append("\n");
            sb.append(" nat (inside,outside) dynamic ").append(s.toIp).append("\n\n");
        }
}
        return sb.toString();
    }
}
