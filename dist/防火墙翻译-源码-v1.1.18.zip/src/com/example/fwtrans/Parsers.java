package com.example.fwtrans;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 各家配置解析：把文本转成统一模型 */
final class Parsers {

    private static String[] tok(String line) {
        return line.trim().split("\\s+");
    }

    private static String unq(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    static void parse(String vendor, String text, Model m) {
        switch (vendor) {
            case "华为 USG":
                huawei(text, m);
                break;
            case "华三 H3C":
                h3c(text, m);
                break;
            case "飞塔 Fortinet":
                forti(text, m);
                break;
            case "山石 Hillstone":
                hillstone(text, m);
                break;
            case "Palo Alto":
                pa(text, m);
                break;
            case "Cisco ASA":
                asa(text, m);
                break;
            default:
                m.note("未知源厂商：" + vendor);
        }
    }

    // ================= 华为 USG =================
    private static void huawei(String text, Model m) {
        String addrSet = null;
        String svcSet = null;
        Model.Pol cur = null;

        for (String raw : text.split("\n")) {
            String l = raw.replace("\t", " ").trim();
            if (l.length() == 0 || l.startsWith("#") || l.startsWith("!")) continue;
            String low = l.toLowerCase();
            String[] t = tok(l);

            if (low.startsWith("ip address-set ") && low.contains("type object")) {
                addrSet = t[2];
                svcSet = null;
                cur = null;
                continue;
            }
            if (low.startsWith("ip service-set ") && low.contains("type object")) {
                svcSet = t[2];
                addrSet = null;
                cur = null;
                continue;
            }
            if (low.equals("security-policy") || low.startsWith("security-policy ")) {
                addrSet = null;
                svcSet = null;
                cur = null;
                continue;
            }

            // 地址对象条目
            if (addrSet != null && low.startsWith("address ") && t.length >= 3
                    && Character.isDigit(t[1].charAt(0))) {
                String ip = t[2];
                if (!Model.isIp(ip)) {
                    addrSet = null;
                    continue;
                }
                Model.Addr a = new Model.Addr();
                a.name = addrSet + "_" + t[1];
                a.type = "net";
                a.ip = ip;
                if (t.length >= 5 && t[3].equalsIgnoreCase("mask")) {
                    a.prefix = Model.maskToPrefix(t[4]);
                } else if (t.length >= 4 && (Model.isIp(t[3]) || t[3].matches("\\d+"))) {
                    a.prefix = Model.maskToPrefix(t[3]);
                } else {
                    a.prefix = 32;
                }
                m.addrs.add(a);
                List<String> g = m.addrGroups.get(addrSet);
                if (g == null) {
                    g = new ArrayList<>();
                    m.addrGroups.put(addrSet, g);
                }
                g.add(a.name);
                continue;
            }
            // 服务对象条目
            if (svcSet != null && low.startsWith("service ") && t.length >= 4
                    && Character.isDigit(t[1].charAt(0))) {
                String proto = t[2].toLowerCase();
                String p1 = t[3];
                String p2 = t.length >= 5 ? t[4] : p1;
                Model.Svc s = new Model.Svc();
                s.name = svcSet + "_" + t[1];
                s.proto = proto;
                s.port = (p1.equals(p2) ? p1 : p1 + "-" + p2);
                m.svcs.add(s);
                List<String> g2 = m.svcGroups.get(svcSet);
                if (g2 == null) {
                    g2 = new ArrayList<>();
                    m.svcGroups.put(svcSet, g2);
                }
                g2.add(s.name);
                continue;
            }

            // 策略规则
            if (low.startsWith("rule name ")) {
                Model.Pol p = new Model.Pol();
                p.name = l.substring("rule name ".length()).trim();
                if (p.name.startsWith("\"")) p.name = unq(p.name);
                m.pols.add(p);
                cur = p;
                continue;
            }
            if (cur != null) {
                if (low.startsWith("source-zone ")) {
                    String z = h3cZone(l.substring("source-zone ".length()));
                    if (z.length() > 0) {
                        if (!cur.from.contains(z)) cur.from.add(z);
                        else cur.zonesMore = true;
                    }
                    continue;
                }
                if (low.startsWith("destination-zone ")) {
                    String z = h3cZone(l.substring("destination-zone ".length()));
                    if (z.length() > 0) {
                        if (!cur.to.contains(z)) cur.to.add(z);
                        else cur.toMore = true;
                    }
                    continue;
                }
                if (low.startsWith("source-address ")) {
                    addRef(m, cur.src, l.substring("source-address ".length()).trim(), true);
                    continue;
                }
                if (low.startsWith("destination-address ")) {
                    addRef(m, cur.dst, l.substring("destination-address ".length()).trim(), false);
                    continue;
                }
                if (low.startsWith("service ")) {
                    String v = l.substring("service ".length()).trim();
                    String nm = v.replace("service-set ", "").trim();
                    List<String> g = m.svcGroups.get(nm);
                    if (g != null) cur.svc.addAll(g);
                    else cur.svc.add(nm);
                    continue;
                }
                if (low.startsWith("action ")) {
                    String a = l.substring("action ".length()).trim();
                    cur.action = a.startsWith("permit") ? "permit" : "deny";
                    continue;
                }
            }

            // NAT：nat static global x inside y
            if (low.startsWith("nat static global ")) {
                String[] parts = l.split("\\s+");
                Model.Dnat d = new Model.Dnat();
                d.name = "dnat_" + m.dnats.size();
                for (int i = 0; i < parts.length; i++) {
                    if ("global".equalsIgnoreCase(parts[i]) && i + 1 < parts.length)
                        d.extIp = parts[i + 1];
                    if ("inside".equalsIgnoreCase(parts[i]) && i + 1 < parts.length)
                        d.intIp = parts[i + 1];
                }
                if (d.extIp != null && d.intIp != null) m.dnats.add(d);
                continue;
            }
            if (low.startsWith("nat outbound")) {
                m.note("华为 nat outbound（源NAT 规则）未转换：" + l);
            }
        }
        if (m.pols.isEmpty() && addrSet != null) m.note("未识别到安全策略段");
    }

    private static void groupAdd(java.util.Map<String, List<String>> map, String key, String member) {
        List<String> g = map.get(key);
        if (g == null) {
            g = new ArrayList<>();
            map.put(key, g);
        }
        g.add(member);
    }

    private static void addRef(Model m, List<String> list, String v, boolean src) {
        v = v.trim();
        if (v.length() == 0) return;
        v = unq(v);
        v = v.replace("address-set ", "").replace("address-group ", "").trim();
        String[] t = v.split("\\s+");
        if (Model.isIp(t[0])) {
            int prefix = 32;
            if (t.length >= 3 && t[1].equalsIgnoreCase("mask")) prefix = Model.maskToPrefix(t[2]);
            else if (t.length >= 2) prefix = Model.maskToPrefix(t[1]);
            list.add(m.ensureAddr(t[0], prefix));
        } else {
            List<String> g = m.addrGroups.get(t[0]);
            if (g != null) list.addAll(g);
            else list.add(t[0]);
        }
    }

    // ================= 华三 H3C =================
    private static void h3c(String text, Model m) {
        String addrGroup = null;
        String svcGroup = null;
        String svcProto = "";
        Model.Pol cur = null;

        for (String raw : text.split("\n")) {
            String l = raw.replace("\t", " ").trim();
            if (l.length() == 0 || l.startsWith("#") || l.startsWith("!")) continue;
            String low = l.toLowerCase();
            String[] t = tok(l);
            // H3C 对象组成员带序号： " 0 network-subnet 10.0.0.0 24"
            if (t.length >= 2 && t[0].matches("\\d+")) {
                l = l.substring(l.indexOf(t[1]));
                low = l.toLowerCase();
                t = tok(l);
            }

            if (low.startsWith("object-group ip address ")) {
                addrGroup = unq(l.substring("object-group ip address ".length()).trim());
                svcGroup = null;
                svcProto = "";
                cur = null;
                continue;
            }
            if (low.startsWith("object-group service ")) {
                String rest = l.substring("object-group service ".length()).trim();
                // 组名可能带引号，后面可选协议
                if (rest.startsWith("\"")) {
                    int endQ = rest.indexOf('"', 1);
                    svcGroup = endQ > 0 ? rest.substring(1, endQ) : rest;
                    String after = endQ > 0 ? rest.substring(endQ + 1).trim() : "";
                    svcProto = after.isEmpty() ? "" : after.split("\\s+")[0].toLowerCase();
                } else if (t.length >= 4) {
                    svcGroup = t[2];
                    svcProto = t[3].toLowerCase();
                } else {
                    svcGroup = t.length >= 3 ? t[2] : "";
                    svcProto = "";
                }
                addrGroup = null;
                cur = null;
                continue;
            }
            if (low.startsWith("security-policy")) {
                addrGroup = null;
                svcGroup = null;
                cur = null;
                continue;
            }

            if (addrGroup != null) {
                // 华三地址组成员写法很多：network-subnet / network / subnet / host / network-range，
                // 也可能不带关键字，直接 "0 10.1.0.0 255.255.0.0"。统一按 token 扫描取 IP 与掩码。
                String kind = t[0].toLowerCase();
                boolean looksMember = kind.startsWith("network") || kind.equals("subnet")
                        || kind.equals("ip-address") || kind.equals("ip") || kind.startsWith("host")
                        || Model.isIp(t[0]);
                if (looksMember) {
                    String ip = null;
                    String other = null;     // 可能是掩码/前缀，也可能是区间结束地址
                    String mask = null;
                    for (int i = 0; i < t.length; i++) {
                        String v = t[i];
                        if (Model.isIp(v)) {
                            if (ip == null) ip = v;
                            else if (other == null) other = v;
                        } else if (v.matches("\\d{1,2}")) {
                            int n = Integer.parseInt(v);
                            if (ip != null && mask == null && n <= 32) mask = v;
                        }
                    }
                    if (ip != null) {
                        Model.Addr a = new Model.Addr();
                        a.name = memberName(m, addrGroup, true);
                        a.ip = ip;
                        boolean range = kind.startsWith("network-range") || kind.equals("range");
                        if (range && other != null) {
                            a.type = "range";
                            a.ip2 = other;
                        } else {
                            a.type = "net";
                            if (other != null && Model.maskToPrefix(other) > 0) mask = other;
                            a.prefix = mask == null ? 32 : Model.maskToPrefix(mask);
                        }
                        m.addrs.add(a);
                        groupAdd(m.addrGroups, addrGroup, a.name);
                        continue;
                    }
                }
            }

            if (svcGroup != null) {
                String proto = svcProto;
                String port = null;
                // 有的版本写成 "0 service tcp destination eq 80"，先剥掉 service
                if (low.startsWith("service ") && t.length >= 2) {
                    l = l.substring(l.indexOf(t[1]));
                    low = l.toLowerCase();
                    t = tok(l);
                }
                if (low.startsWith("tcp ") || low.startsWith("udp ")) {
                    proto = t[0].toLowerCase();
                    port = h3cPort(t, 1);
                } else if (low.startsWith("port eq ")) {
                    port = t.length >= 3 ? t[2] : null;
                } else if (low.startsWith("port range ")) {
                    port = t.length >= 4 ? t[2] + "-" + t[3] : null;
                } else if (low.startsWith("destination eq ")) {
                    port = t.length >= 3 ? t[2] : null;
                } else if (low.startsWith("destination range ")) {
                    port = t.length >= 4 ? t[2] + "-" + t[3] : null;
                }
                if (port != null) port = h3cPortName(port);
                if (!proto.isEmpty() && port != null && port.length() > 0) {
                    Model.Svc sv = new Model.Svc();
                    sv.name = svcGroup;
                    sv.proto = proto;
                    sv.port = port;
                    m.svcs.add(sv);
                    groupAdd(m.svcGroups, svcGroup, sv.name);
                }
                continue;
            }

            if (low.startsWith("rule name ") || low.matches("^rule\\s+\\d+.*")) {
                String name;
                int nameAt = low.indexOf("name ");
                if (nameAt >= 0) {
                    name = unq(l.substring(nameAt + "name ".length()).trim());
                } else {
                    name = "rule_" + t[1];
                }
                Model.Pol p = new Model.Pol();
                p.name = name;
                m.pols.add(p);
                cur = p;
                continue;
            }
            if (cur != null) {
                if (low.startsWith("source-zone ")) {
                    String z = h3cZone(l.substring("source-zone ".length()));
                    if (z.length() > 0) {
                        if (!cur.from.contains(z)) cur.from.add(z);
                        else cur.zonesMore = true;
                    }
                    continue;
                }
                if (low.startsWith("destination-zone ")) {
                    String z = h3cZone(l.substring("destination-zone ".length()));
                    if (z.length() > 0) {
                        if (!cur.to.contains(z)) cur.to.add(z);
                        else cur.toMore = true;
                    }
                    continue;
                }
                if (low.startsWith("source-ip ")) {
                    addRef(m, cur.src, l.substring("source-ip ".length()), true);
                    continue;
                }
                if (low.startsWith("destination-ip ")) {
                    addRef(m, cur.dst, l.substring("destination-ip ".length()), false);
                    continue;
                }
                if (low.startsWith("service ")) {
                    String nm = unq(l.substring("service ".length()).trim());
                    if (!cur.svc.contains(nm)) cur.svc.add(nm);
                    continue;
                }
                if (low.startsWith("action ")) {
                    String a = l.substring("action ".length()).trim();
                    cur.action = a.startsWith("pass") || a.startsWith("permit") ? "permit" : "deny";
                    continue;
                }
            }

            // nat server protocol tcp global 1.1.1.1 80 inside 192.168.1.10 80
            if (low.startsWith("nat server ")) {
                Model.Dnat d = new Model.Dnat();
                d.name = "dnat_" + m.dnats.size();
                Matcher mm = Pattern.compile(
                        "protocol\\s+(tcp|udp)\\s+global\\s+([0-9.]+)\\s*(\\d+)?\\s+inside\\s+([0-9.]+)\\s*(\\d+)?",
                        Pattern.CASE_INSENSITIVE).matcher(l);
                if (mm.find()) {
                    d.proto = mm.group(1).toLowerCase();
                    d.extIp = mm.group(2);
                    d.extPort = mm.group(3) == null ? "" : mm.group(3);
                    d.intIp = mm.group(4);
                    d.intPort = mm.group(5) == null ? d.extPort : mm.group(5);
                    m.dnats.add(d);
                }
                continue;
            }
            if (low.startsWith("nat outbound")) {
                m.note("华三 nat outbound（源NAT）未转换：" + l);
            }
        }
    }

    /** 组内成员命名：单成员用组名，多成员为 组名_0/组名_1…（第二个成员进来时给第一个补 _0） */
    private static String memberName(Model m, String group, boolean isAddr) {
        // 组内所有成员共用组名：输出时按组聚合，多条成员命令挂在同一组下
        return group;
    }

    /** 华三端口名 → 数字：eq www / eq https 这类写法 */
    private static String h3cPortName(String v) {
        String[] names = {"ftp-data:20", "ftp:21", "ssh:22", "telnet:23", "smtp:25",
                "domain:53", "dns:53", "www:80", "http:80", "pop3:110", "ntp:123",
                "imap:143", "snmp:161", "ldap:389", "https:443", "syslog:514",
                "tftp:69", "radius:1812"};
        String low = v.toLowerCase();
        for (String n : names) {
            String[] kv = n.split(":");
            if (kv[0].equals(low)) return kv[1];
        }
        return v;
    }

    /** 华三服务端口：t[start] 或 t[start] t[start+1]（相同则单端口，否则区间） */
    private static String h3cPort(String[] t, int start) {
        String p1 = null;
        String p2 = null;
        for (int i = start; i < t.length; i++) {
            String v = h3cPortName(t[i]);
            if (v.matches("\\d+-\\d+")) {
                if (p1 == null) p1 = v;
                else if (p2 == null) p2 = v;
            } else if (v.matches("\\d+")) {
                if (p1 == null) p1 = v;
                else if (p2 == null) p2 = v;
            }
            // destination / source / eq / range 等关键字直接跳过
        }
        if (p1 == null) return "";
        if (p2 == null || p1.equals(p2)) return p1;
        return p1 + "-" + p2;
    }

    // ================= 飞塔 Fortinet =================
    private static void forti(String text, Model m) {
        String section = "";
        String curName = null;
        Model.Addr a = null;
        Model.Svc s = null;
        Model.Pol p = null;
        Model.Dnat d = null;
        String poolStart = null;

        for (String raw : text.split("\n")) {
            String l = raw.trim();
            if (l.length() == 0 || l.startsWith("#")) continue;
            String low = l.toLowerCase();

            if (low.startsWith("config firewall address")) {
                section = "addr";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall service custom")) {
                section = "svc";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall policy")) {
                section = "pol";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall vip")) {
                section = "vip";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall ippool")) {
                section = "ippool";
                curName = null;
                continue;
            }
            if (low.startsWith("config ") || low.equals("end")) {
                section = "";
                curName = null;
                continue;
            }

            if (low.startsWith("edit ")) {
                curName = unq(l.substring(5));
                a = null;
                s = null;
                p = null;
                d = null;
                if ("addr".equals(section)) {
                    a = new Model.Addr();
                    a.name = curName;
                    m.addrs.add(a);
                } else if ("svc".equals(section)) {
                    s = new Model.Svc();
                    s.name = curName;
                    m.svcs.add(s);
                } else if ("pol".equals(section)) {
                    p = new Model.Pol();
                    p.name = curName;
                    m.pols.add(p);
                } else if ("vip".equals(section)) {
                    d = new Model.Dnat();
                    d.name = curName;
                }
                continue;
            }

            if (low.startsWith("set ")) {
                String body = l.substring(4).trim();
                String key = body.split("\\s+")[0].toLowerCase();
                String val = body.substring(body.indexOf(key) + key.length()).trim();
                if ("addr".equals(section) && a != null) {
                    if (key.equals("subnet")) {
                        String[] t = val.split("\\s+");
                        a.type = "net";
                        a.ip = t[0];
                        a.prefix = Model.maskToPrefix(t.length > 1 ? t[1] : "32");
                    } else if (key.equals("type") && val.contains("fqdn")) {
                        a.type = "fqdn";
                    } else if (key.equals("fqdn")) {
                        a.fqdn = unq(val);
                        a.type = "fqdn";
                    } else if (key.equals("start-ip")) {
                        a.ip = unq(val);
                    } else if (key.equals("end-ip")) {
                        a.type = "range";
                        a.ip2 = unq(val);
                    }
                } else if ("svc".equals(section) && s != null) {
                    if (key.equals("tcp-portrange")) {
                        s.proto = "tcp";
                        s.port = portRange(unq(val));
                    } else if (key.equals("udp-portrange")) {
                        s.proto = "udp";
                        s.port = portRange(unq(val));
                    } else if (key.equals("protocol")) {
                        String v2 = unq(val).toUpperCase();
                        if (v2.contains("ICMP")) {
                            s.proto = "icmp";
                            s.port = "";
                        } else if (v2.contains("TCP")) {
                            s.proto = "tcp";
                        } else if (v2.contains("UDP")) {
                            s.proto = "udp";
                        }
                    }
                } else if ("pol".equals(section) && p != null) {
                    if (key.equals("name")) p.name = unq(val);
                    else if (key.equals("srcintf")) addIfList(p.from, val);
                    else if (key.equals("dstintf")) addIfList(p.to, val);
                    else if (key.equals("srcaddr")) addAll(m, p.src, val, true);
                    else if (key.equals("dstaddr")) addAll(m, p.dst, val, false);
                    else if (key.equals("service")) addAllSvc(p.svc, val);
                    else if (key.equals("action")) p.action = val.contains("accept") ? "permit" : "deny";
                    else if (key.equals("nat") && val.contains("enable"))
                        m.note("飞塔策略 " + p.name + " 开启了 NAT（需在目标侧手工确认源NAT 地址）");
                } else if ("vip".equals(section) && d != null) {
                    if (key.equals("extip")) d.extIp = unq(val);
                    else if (key.equals("mappedip")) d.intIp = unq(val);
                    else if (key.equals("extport")) d.extPort = unq(val);
                    else if (key.equals("mappedport")) d.intPort = unq(val);
                    else if (key.equals("protocol")) d.proto = unq(val).toLowerCase();
                } else if ("ippool".equals(section)) {
                    if (key.equals("startip")) poolStart = unq(val);
                }
            }
            if (low.equals("next")) {
                if ("vip".equals(section) && d != null && d.extIp != null && d.intIp != null) {
                    Model.Dnat dd = d;
                    m.dnats.add(dd);
                    d = null;
                }
                if ("ippool".equals(section) && poolStart != null) {
                    Model.Snat sn = new Model.Snat();
                    sn.name = curName;
                    sn.toIp = poolStart;
                    m.snats.add(sn);
                    m.note("飞塔 ippool " + curName + " 已转为源NAT 地址池，需要在目标防火墙策略里绑定");
                    poolStart = null;
                }
                curName = null;
            }
        }
    }

    private static String portRange(String v) {
        // "80" 或 "80-90" 或 "80 90" 或 "80-90 100-110"
        v = v.trim();
        String first = v.split("\\s+")[0];
        return first.replace(":", "-");
    }

    /** 接口/区域名列表：支持 "a" "b" 多个带引号值，也支持空格分隔 */
    private static void addIfList(List<String> list, String val) {
        if (val == null) return;
        java.util.regex.Matcher mt = java.util.regex.Pattern.compile("\"([^\"]*)\"").matcher(val);
        boolean found = false;
        while (mt.find()) {
            found = true;
            String v = mt.group(1).trim();
            if (v.length() > 0 && !"any".equalsIgnoreCase(v) && !list.contains(v)) list.add(v);
        }
        if (!found) {
            for (String v : val.trim().split("\\s+")) {
                if (v.length() > 0 && !"any".equalsIgnoreCase(v) && !list.contains(v)) list.add(v);
            }
        }
    }

    private static void addAll(Model m, List<String> list, String val, boolean src) {
        Matcher q = Pattern.compile("\"([^\"]+)\"").matcher(val);
        List<String> names = new ArrayList<>();
        while (q.find()) names.add(q.group(1));
        if (names.isEmpty()) names.add(unq(val));
        for (String n : names) {
            if (n.equalsIgnoreCase("all") || n.equalsIgnoreCase("any")) {
                list.add("any");
            } else if (Model.isIp(n)) {
                list.add(m.ensureAddr(n, 32));
            } else {
                list.add(n);
            }
        }
    }

    private static void addAllSvc(List<String> list, String val) {
        Matcher q = Pattern.compile("\"([^\"]+)\"").matcher(val);
        boolean any = false;
        while (q.find()) {
            String n = q.group(1);
            if (n.equalsIgnoreCase("ALL") || n.equalsIgnoreCase("any")) any = true;
            else list.add(n);
        }
        if (list.isEmpty() && !any) {
            String n = unq(val);
            if (n.equalsIgnoreCase("ALL") || n.equalsIgnoreCase("any")) any = true;
            else list.add(n);
        }
        if (any) list.add(0, "any");
    }

    // ================= 山石 Hillstone =================
    private static void hillstone(String text, Model m) {
        // 真机导出是块式：
        //   address "X"
        //     ip 10.0.0.0/24 / range a b / member "Y"
        //   exit
        //   service "X"
        //     tcp dst-port 22  或 tcp dst-port 5900 7000
        //   exit
        //   servesgroup "G"
        //     member "S1" ...
        //   exit
        //   rule id 3
        //     src-zone ... dst-zone ... src-addr ... dst-addr ... service ... action ... name ...
        //   exit
        java.util.Map<String, List<String>> addrEntries = new java.util.LinkedHashMap<>();
        java.util.Map<String, List<String>> addrMembers = new java.util.LinkedHashMap<>();
        java.util.Map<String, String[]> svcDef = new java.util.LinkedHashMap<>();
        java.util.Map<String, List<String>> svcMembers = new java.util.LinkedHashMap<>();

        String block = null;
        String name = null;
        Model.Pol cur = null;

        for (String raw : text.split("\n")) {
            String l = raw.trim();
            if (l.length() == 0 || l.startsWith("#") || l.startsWith("!")) continue;
            String low = l.toLowerCase();
            String[] t = tok(l);

            if (low.equals("exit")) {
                block = null;
                name = null;
                cur = null;
                continue;
            }
            if ("rule".equals(block) && cur != null) {
                if (low.startsWith("src-zone ")) {
                    String z = unq(l.substring("src-zone ".length()).trim());
                    if (isAnyZone(z)) continue;
                    if (!cur.from.contains(z)) cur.from.add(z);
                    else cur.zonesMore = true;
                    continue;
                }
                if (low.startsWith("dst-zone ")) {
                    String z = unq(l.substring("dst-zone ".length()).trim());
                    if (isAnyZone(z)) continue;
                    if (!cur.to.contains(z)) cur.to.add(z);
                    else cur.toMore = true;
                    continue;
                }
                if (low.startsWith("src-addr ")) {
                    String v = unq(l.substring("src-addr ".length()).trim());
                    if (!"Any".equalsIgnoreCase(v) && !"all".equalsIgnoreCase(v)) cur.src.add(v);
                    continue;
                }
                if (low.startsWith("dst-addr ")) {
                    String v = unq(l.substring("dst-addr ".length()).trim());
                    if (!"Any".equalsIgnoreCase(v) && !"all".equalsIgnoreCase(v)) cur.dst.add(v);
                    continue;
                }
                if (low.startsWith("service ")) {
                    String v = unq(l.substring("service ".length()).trim());
                    if (!"Any".equalsIgnoreCase(v) && !cur.svc.contains(v)) cur.svc.add(v);
                    continue;
                }
                if (low.startsWith("action ")) {
                    String act = l.substring("action ".length()).trim().toLowerCase();
                    cur.action = (act.startsWith("permit") || act.startsWith("accept")) ? "permit" : "deny";
                    continue;
                }
                if (low.startsWith("name ")) {
                    String nmz = unq(l.substring("name ".length()).trim());
                    if (nmz.length() > 0) cur.name = nmz;
                    continue;
                }
            }

            if (low.startsWith("address ")) {
                block = "addr";
                name = t.length >= 2 ? unq(t[1]) : null;
                if (name != null) {
                    if (!addrEntries.containsKey(name)) addrEntries.put(name, new ArrayList<String>());
                    if (!addrMembers.containsKey(name)) addrMembers.put(name, new ArrayList<String>());
                }
                continue;
            }
            if (low.startsWith("servgroup ")) {
                block = "servgroup";
                name = t.length >= 2 ? unq(t[1]) : null;
                if (name != null && !svcMembers.containsKey(name)) svcMembers.put(name, new ArrayList<String>());
                continue;
            }
            if (low.startsWith("service ") && t.length >= 2) {
                block = "svc";
                name = unq(t[1]);
                continue;
            }
            if (low.startsWith("rule id ") && t.length >= 3) {
                block = "rule";
                cur = new Model.Pol();
                cur.name = "rule_" + t[2];
                m.pols.add(cur);
                continue;
            }

            if (block == null) continue;

            if ("addr".equals(block) && name != null) {
                if (low.startsWith("ip ")) {
                    String v = unq(t[1]);
                    if (v.indexOf(':') >= 0) continue;       // IPv6 跳过
                    List<String> es = addrEntries.get(name);
                    String item = "ip:" + v;
                    if (!es.contains(item)) es.add(item);
                    continue;
                }
                if (low.startsWith("range ") && t.length >= 3) {
                    List<String> es = addrEntries.get(name);
                    String item = "range:" + t[1] + "-" + t[2];
                    if (!es.contains(item)) es.add(item);
                    continue;
                }
                if (low.startsWith("member ")) {
                    String mn = unq(l.substring("member ".length()).trim());
                    List<String> ms = addrMembers.get(name);
                    if (ms != null && !ms.contains(mn)) ms.add(mn);
                    continue;
                }
                continue;
            }

            if ("svc".equals(block) && name != null) {
                if (low.startsWith("tcp ") || low.startsWith("udp ")) {
                    String proto = t[0].toLowerCase();
                    String port = "";
                    int a = -1;
                    int b = -1;
                    for (int i = 1; i < t.length; i++) {
                        if (t[i].matches("\\d+")) {
                            if (a < 0) a = Integer.parseInt(t[i]);
                            else if (b < 0) b = Integer.parseInt(t[i]);
                        }
                    }
                    if (a >= 0) port = b < 0 || a == b ? String.valueOf(a) : (a + "-" + b);
                    svcDef.put(name, new String[]{proto, port});
                    continue;
                }
                if (low.startsWith("icmp")) {
                    svcDef.put(name, new String[]{"icmp", ""});
                    continue;
                }
                continue;
            }

            if ("servgroup".equals(block) && name != null) {
                if (low.startsWith("member ") || low.startsWith("service ")) {
                    String mn = unq(l.substring(low.indexOf(' ') + 1).trim());
                    List<String> ms = svcMembers.get(name);
                    if (ms != null && !ms.contains(mn)) ms.add(mn);
                    continue;
                }
                continue;
            }


        }

        // 1) 地址对象：把成员组展开成具体 IP（组内嵌套也支持）
        java.util.Set<String> done = new java.util.HashSet<>();
        for (String nm : addrEntries.keySet()) {
            List<String> flat = flattenAddr(nm, addrEntries, addrMembers, done);
            if (flat.isEmpty()) continue;
            if ("IPv6-any".equalsIgnoreCase(nm) || "Any".equalsIgnoreCase(nm)
                    || "any".equalsIgnoreCase(nm)) continue;
            List<String> members = new ArrayList<>();
            for (String item : flat) {
                Model.Addr a = new Model.Addr();
                a.name = nm;
                if (item.startsWith("ip:")) {
                    String v = item.substring(3);
                    if (v.contains("/")) {
                        String[] sp = v.split("/");
                        a.ip = sp[0];
                        a.prefix = Model.maskToPrefix(sp[1]);
                    } else {
                        a.ip = v;
                        a.prefix = 32;
                    }
                } else {
                    String v = item.substring(6);
                    String[] sp = v.split("-");
                    a.type = "range";
                    a.ip = sp[0];
                    a.ip2 = sp.length > 1 ? sp[1] : sp[0];
                }
                m.addrs.add(a);
                members.add(nm);
            }
            m.addrGroups.put(nm, members);
        }

        // 2) 服务对象
        for (java.util.Map.Entry<String, String[]> e : svcDef.entrySet()) {
            String[] d = e.getValue();
            if (d[1] == null || d[1].length() == 0) continue;
            Model.Svc sv = new Model.Svc();
            sv.name = e.getKey();
            sv.proto = d[0];
            sv.port = d[1];
            m.svcs.add(sv);
        }
        for (java.util.Map.Entry<String, List<String>> e : svcMembers.entrySet()) {
            m.svcGroups.put(e.getKey(), e.getValue());
        }

        // 3) 策略里没有定义块的服务（预定义服务）按名字推出协议与端口
        for (Model.Pol p : m.pols) {
            for (String n : p.svc) {
                if (svcDef.containsKey(n) || m.svcGroups.containsKey(n)) continue;
                String[] g = hillstoneSvcGuess(n);
                if (g == null) continue;
                boolean exists = false;
                for (Model.Svc sv : m.svcs) if (sv.name.equals(n)) { exists = true; break; }
                if (exists) continue;
                Model.Svc sv = new Model.Svc();
                sv.name = n;
                sv.proto = g[0];
                sv.port = g[1];
                m.svcs.add(sv);
            }
        }

        // 4) 仍未识别的服务名：提示用户
        List<String> unknownSvc = new ArrayList<>();
        for (Model.Pol p : m.pols) {
            for (String n : p.svc) {
                boolean found = false;
                for (Model.Svc sv : m.svcs) if (sv.name.equals(n)) { found = true; break; }
                if (!found && !unknownSvc.contains(n)) unknownSvc.add(n);
            }
        }
        if (!unknownSvc.isEmpty()) {
            m.note("这些服务名在配置里没有定义，也推不出端口，输出里只保留了名字，请按实际端口补："
                    + unknownSvc.toString());
        }

        // 5) 策略里的服务组展开成具体服务名
        for (Model.Pol p : m.pols) {
            List<String> list = new ArrayList<>();
            for (String n : p.svc) {
                List<String> mem = m.svcGroups.get(n);
                if (mem != null) {
                    for (String x : mem) if (!list.contains(x)) list.add(x);
                } else if (!list.contains(n)) list.add(n);
            }
            p.svc.clear();
            p.svc.addAll(list);
            // 地址引用去重
            p.src = dedup(p.src);
            p.dst = dedup(p.dst);
        }

        int zoneMore = 0;
        for (Model.Pol p : m.pols) if (p.zonesMore || p.toMore) zoneMore++;
        if (zoneMore > 0) {
            m.note("有 " + zoneMore + " 条策略配置了多个区域，目标侧每条规则只保留一个区域，已保留列表中的第一个，请人工核对是否需要拆成多条规则");
        }
    }

    /** 区域名：去引号，多值取第一个，any/all 视为未指定 */
    private static String h3cZone(String v) {
        String t = unq(v.trim());
        if (isAnyZone(t)) return "";
        String[] parts = t.split("\\s+");
        return parts.length > 0 ? parts[0] : "";
    }

    private static boolean isAnyZone(String z) {
        String v = z == null ? "" : z.trim();
        return v.length() == 0 || v.equalsIgnoreCase("any") || v.equalsIgnoreCase("all");
    }

    /** 预定义服务名 → 协议/端口 */
    private static String[] hillstoneSvcGuess(String name) {
        String up = name.toUpperCase();
        if ("ICMP".equals(up) || "PING".equals(up)) return new String[]{"icmp", ""};
        java.util.regex.Matcher mt = java.util.regex.Pattern
                .compile("(TCP|UDP)-\\d+(?:[-_]\\d+)?").matcher(up);
        if (mt.matches()) {
            String[] parts = up.split("[-_]");
            String proto = parts[0].toLowerCase();
            String port = parts.length >= 3 ? parts[1] + "-" + parts[2] : parts[1];
            return new String[]{proto, port};
        }
        String[][] table = {
                {"HTTP", "80", "tcp"}, {"HTTPS", "443", "tcp"}, {"RDP", "3389", "tcp"},
                {"SYSLOG", "514", "udp"}, {"SYSLOG-TCP", "514", "tcp"},
                {"NTP", "123", "udp"}, {"NTP-TCP", "123", "tcp"},
                {"SSH", "22", "tcp"}, {"FTP", "21", "tcp"}, {"FTP-DATA", "20", "tcp"},
                {"SMTP", "25", "tcp"}, {"DNS", "53", "udp"}, {"SNMP", "161", "udp"},
                {"MYSQL", "3306", "tcp"}, {"MSSQL", "1433", "tcp"},
                {"ORACLE", "1521", "tcp"}, {"TELNET", "23", "tcp"},
                {"POP3", "110", "tcp"}, {"IMAP", "143", "tcp"}, {"SMTPS", "465", "tcp"},
        };
        for (String[] row : table) {
            if (row[0].equals(up)) return new String[]{row[2], row[1]};
        }
        return null;
    }

    private static List<String> dedup(List<String> in) {
        List<String> out = new ArrayList<>();
        for (String v : in) if (!out.contains(v)) out.add(v);
        return out;
    }

    /** 把地址组递归展开成 ip:/range: 条目 */
    private static List<String> flattenAddr(String name, java.util.Map<String, List<String>> entries,
                                            java.util.Map<String, List<String>> members,
                                            java.util.Set<String> visiting) {
        List<String> out = new ArrayList<>();
        if (!visiting.add(name)) return out;
        List<String> own = entries.get(name);
        if (own != null) for (String v : own) if (!out.contains(v)) out.add(v);
        List<String> ms = members.get(name);
        if (ms != null) {
            for (String mn : ms) {
                // 成员可能是普通地址对象，也可能又是组
                List<String> sub = flattenAddr(mn, entries, members, visiting);
                for (String v : sub) if (!out.contains(v)) out.add(v);
            }
        }
        return out;
    }

    private static void addName(Model m, List<String> list, String n) {
        if (n == null) return;
        if (n.equalsIgnoreCase("any") || n.equalsIgnoreCase("all")) list.add("any");
        else if (Model.isIp(n)) list.add(m.ensureAddr(n, 32));
        else list.add(n);
    }

    // ================= Palo Alto（XML） =================
    private static void pa(String text, Model m) {
        String addrRegion = region(text, "<address>", "</address>");
        Matcher e = Pattern.compile("<entry\\s+name=\"([^\"]+)\"[^>]*>(.*?)</entry>",
                Pattern.DOTALL).matcher(addrRegion);
        while (e.find()) {
            Model.Addr a = new Model.Addr();
            a.name = e.group(1);
            String b = e.group(2);
            Matcher net = Pattern.compile("<ip-netmask>([^<]+)</ip-netmask>").matcher(b);
            Matcher host = Pattern.compile("<ip-address>([^<]+)</ip-address>").matcher(b);
            Matcher rng = Pattern.compile("<ip-range>([^<]+)</ip-range>").matcher(b);
            Matcher fq = Pattern.compile("<fqdn>([^<]+)</fqdn>").matcher(b);
            if (net.find()) {
                String v = net.group(1).trim();
                if (v.contains("/")) {
                    a.ip = v.split("/")[0];
                    a.prefix = Model.maskToPrefix(v.split("/")[1]);
                } else {
                    a.ip = v;
                    a.prefix = 32;
                }
            } else if (host.find()) {
                a.ip = host.group(1).trim();
                a.prefix = 32;
            } else if (rng.find()) {
                String[] sp = rng.group(1).trim().split("-");
                a.type = "range";
                a.ip = sp[0].trim();
                a.ip2 = sp.length > 1 ? sp[1].trim() : sp[0].trim();
            } else if (fq.find()) {
                a.type = "fqdn";
                a.fqdn = fq.group(1).trim();
            } else {
                continue;
            }
            m.addrs.add(a);
        }

        String svcRegion = region(text, "<service>", "</service>");
        Matcher se = Pattern.compile("<entry\\s+name=\"([^\"]+)\"[^>]*>(.*?)</entry>",
                Pattern.DOTALL).matcher(svcRegion);
        while (se.find()) {
            Model.Svc s = new Model.Svc();
            s.name = se.group(1);
            String b = se.group(2);
            if (b.contains("<tcp>")) s.proto = "tcp";
            else if (b.contains("<udp>")) s.proto = "udp";
            Matcher pt = Pattern.compile("<port>([^<]+)</port>").matcher(b);
            if (pt.find()) s.port = pt.group(1).trim();
            m.svcs.add(s);
        }

        String rulesRegion = region(text, "<rules>", "</rules>");
        Matcher re = Pattern.compile("<entry\\s+name=\"([^\"]+)\"[^>]*>(.*?)</entry>",
                Pattern.DOTALL).matcher(rulesRegion);
        while (re.find()) {
            String b = re.group(2);
            if (b.contains("<disabled>yes</disabled>")) continue;
            Model.Pol p = new Model.Pol();
            p.name = re.group(1);
            p.from.add(firstMember(b, "from"));
            p.to.add(firstMember(b, "to"));
            p.src.addAll(members(b, "source"));
            p.dst.addAll(members(b, "destination"));
            p.svc.addAll(members(b, "service"));
            Matcher ac = Pattern.compile("<action>([^<]+)</action>").matcher(b);
            if (ac.find()) p.action = ac.group(1).trim().contains("allow") ? "permit" : "deny";
            if (p.src.isEmpty()) p.src.add("any");
            if (p.dst.isEmpty()) p.dst.add("any");
            if (p.svc.isEmpty()) p.svc.add("any");
            m.pols.add(p);
        }

        // NAT：source-translation / destination-translation
        Matcher dn = Pattern.compile(
                "<destination-translation>(.*?)</destination-translation>", Pattern.DOTALL)
                .matcher(text);
        while (dn.find()) {
            Model.Dnat d = new Model.Dnat();
            d.name = "dnat_" + m.dnats.size();
            String b = dn.group(1);
            Matcher ip = Pattern.compile("<translated-address>\\s*<member>([^<]+)</member>",
                    Pattern.DOTALL).matcher(b);
            if (ip.find()) d.intIp = ip.group(1).trim();
            Matcher pt = Pattern.compile("<translated-port>([^<]+)</translated-port>").matcher(b);
            if (pt.find()) d.intPort = pt.group(1).trim();
            if (d.intIp != null) {
                d.extIp = d.intIp;
                m.dnats.add(d);
                m.note("Palo Alto 目的NAT 规则缺少公网地址映射信息，请在目标侧核对 extIp/extPort");
            }
        }

        Matcher sn = Pattern.compile(
                "<source-translation>(.*?)</source-translation>", Pattern.DOTALL).matcher(text);
        while (sn.find()) {
            Model.Snat s = new Model.Snat();
            s.name = "snat_" + m.snats.size();
            Matcher ip = Pattern.compile("<translated-address>\\s*<member>([^<]+)</member>",
                    Pattern.DOTALL).matcher(sn.group(1));
            if (ip.find()) {
                s.toIp = ip.group(1).trim();
                m.snats.add(s);
            }
        }
    }

    private static String region(String text, String open, String close) {
        int a = text.indexOf(open);
        if (a < 0) return "";
        int b = text.indexOf(close, a);
        if (b < 0) return text.substring(a);
        return text.substring(a, b);
    }

    private static String firstMember(String block, String tag) {
        Matcher m = Pattern.compile("<" + tag + ">\\s*<member>([^<]+)</member>", Pattern.DOTALL)
                .matcher(block);
        return m.find() ? m.group(1).trim() : "";
    }

    private static List<String> members(String block, String tag) {
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("<" + tag + ">(.*?)</" + tag + ">", Pattern.DOTALL)
                .matcher(block);
        if (!m.find()) return out;
        Matcher mm = Pattern.compile("<member>([^<]+)</member>").matcher(m.group(1));
        while (mm.find()) out.add(mm.group(1).trim());
        return out;
    }

    // ================= Cisco ASA =================
    private static void asa(String text, Model m) {
        String objName = null;
        Model.Addr a = null;
        Model.Svc s = null;

        for (String raw : text.split("\n")) {
            String l = raw.trim();
            if (l.length() == 0 || l.startsWith("!") || l.startsWith("#")) continue;
            String low = l.toLowerCase();

            if (low.startsWith("object network ")) {
                objName = l.substring("object network ".length()).trim();
                a = new Model.Addr();
                a.name = objName;
                m.addrs.add(a);
                s = null;
                continue;
            }
            if (low.startsWith("object service ")) {
                objName = l.substring("object service ".length()).trim();
                s = new Model.Svc();
                s.name = objName;
                m.svcs.add(s);
                a = null;
                continue;
            }
            if (low.startsWith("object ") || low.startsWith("access-list ")
                    || low.startsWith("interface ") || low.startsWith("nat ")
                    || low.startsWith("route ")) {
                if (!low.startsWith("object network") && !low.startsWith("object service")) {
                    objName = null;
                }
            }

            if (a != null) {
                if (low.startsWith("subnet ") && tok(l).length >= 3) {
                    String[] t = tok(l);
                    a.type = "net";
                    a.ip = t[1];
                    a.prefix = Model.maskToPrefix(t[2]);
                } else if (low.startsWith("host ") && tok(l).length >= 2) {
                    a.type = "net";
                    a.ip = tok(l)[1];
                    a.prefix = 32;
                } else if (low.startsWith("range ") && tok(l).length >= 3) {
                    a.type = "range";
                    a.ip = tok(l)[1];
                    a.ip2 = tok(l)[2];
                } else if (low.startsWith("fqdn ")) {
                    a.type = "fqdn";
                    a.fqdn = l.substring(5).trim();
                }
            }
            if (s != null && low.startsWith("service ")) {
                String[] t = tok(l);
                if (t.length >= 5) {
                    s.proto = t[1];
                    s.port = t[4];
                }
            }

            // access-list OUT extended permit tcp object A object B eq 80
            if (low.startsWith("access-list ")) {
                String[] t = tok(l);
                if (t.length < 5) continue;
                String aclName = t[1];
                boolean ext = false;
                for (String x : t) if (x.equalsIgnoreCase("extended")) ext = true;
                if (!ext) continue;
                Model.Pol p = new Model.Pol();
                p.name = aclName;
                p.from.add(aclName);
                p.to.add(aclName);
                int i = 3;
                p.action = t[i].toLowerCase().startsWith("permit") ? "permit" : "deny";
                i++;
                String proto = t[i].toLowerCase();
                i++;
                // 源
                if (i < t.length && t[i].equalsIgnoreCase("any")) {
                    p.src.add("any");
                    i++;
                } else if (i < t.length && t[i].equalsIgnoreCase("object") && i + 1 < t.length) {
                    p.src.add(t[i + 1]);
                    i += 2;
                } else if (i < t.length && Model.isIp(t[i])) {
                    p.src.add(m.ensureAddr(t[i], 32));
                    i++;
                }
                // 目的
                if (i < t.length && t[i].equalsIgnoreCase("any")) {
                    p.dst.add("any");
                    i++;
                } else if (i < t.length && t[i].equalsIgnoreCase("object") && i + 1 < t.length) {
                    p.dst.add(t[i + 1]);
                    i += 2;
                } else if (i < t.length && Model.isIp(t[i])) {
                    p.dst.add(m.ensureAddr(t[i], 32));
                    i++;
                }
                // 端口
                String port = "";
                if (i < t.length && t[i].equalsIgnoreCase("object") && i + 1 < t.length) {
                    p.svc.add(t[i + 1]);
                } else if (i + 1 < t.length && t[i].equalsIgnoreCase("eq")) {
                    port = t[i + 1];
                    p.svc.add(m.ensureSvc(proto, port));
                } else if (proto.equals("ip")) {
                    p.svc.add("any");
                }
                if (p.svc.isEmpty()) p.svc.add("any");
                m.pols.add(p);
                continue;
            }

            if (low.startsWith("nat (") && a != null) {
                Matcher mt = Pattern.compile("nat\\s*\\(([^)]+)\\)\\s*(static|dynamic)\\s*([0-9.]+)?")
                        .matcher(l);
                if (mt.find()) {
                    String ifs = mt.group(1);
                    String kind = mt.group(2);
                    String ip = mt.group(3);
                    String first = ifs.split(",")[0].trim();
                    if ("static".equals(kind) && ip != null) {
                        if (first.equalsIgnoreCase("outside") || first.equalsIgnoreCase("untrust")) {
                            Model.Dnat d = new Model.Dnat();
                            d.name = a.name + "_dnat";
                            d.extIp = ip;
                            d.intIp = a.ip;
                            if (a.type.equals("net") && a.prefix == 32) m.dnats.add(d);
                        } else {
                            Model.Snat sn = new Model.Snat();
                            sn.name = a.name + "_snat";
                            sn.src = a.name;
                            sn.toIp = ip;
                            m.snats.add(sn);
                        }
                    }
                }
                continue;
            }
        }
    }
}
