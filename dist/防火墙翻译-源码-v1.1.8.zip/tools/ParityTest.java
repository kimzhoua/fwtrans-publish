package com.example.fwtrans;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * 网页版与 Java 版的一致性检查：对同一批样例配置，按同样的目标厂商逐段生成，
 * 打印结果供 parity_check.py 与 node 侧输出逐字比对。
 *
 * 用法：java com.example.fwtrans.ParityTest tools/parity_samples.txt
 */
public class ParityTest {

    private static final String[] VENDORS = {
            "华为 USG", "华三 H3C", "飞塔 Fortinet", "山石 Hillstone", "Palo Alto", "Cisco ASA"
    };

    static class Sample {
        String name;
        String vendor;
        String body;
    }

    public static void main(String[] args) throws Exception {
        String text = new String(Files.readAllBytes(Paths.get(args[0])), StandardCharsets.UTF_8);
        List<Sample> samples = new ArrayList<>();
        Sample cur = null;
        StringBuilder body = new StringBuilder();
        for (String raw : text.split("\n", -1)) {
            if (raw.startsWith("### ")) {
                if (cur != null) {
                    cur.body = body.toString();
                    samples.add(cur);
                    body.setLength(0);
                }
                String head = raw.substring(4).trim();
                String[] parts = head.split("\\|");
                cur = new Sample();
                cur.name = parts[0].trim();
                cur.vendor = parts.length > 1 ? parts[1].trim() : VENDORS[0];
            } else if (cur != null) {
                body.append(raw).append('\n');
            }
        }
        if (cur != null) {
            cur.body = body.toString();
            samples.add(cur);
        }

        StringBuilder out = new StringBuilder();
        for (Sample s : samples) {
            for (String dst : VENDORS) {
                if (!"Palo Alto".equals(dst)) {
                    run(out, s, dst, true);
                } else {
                    run(out, s, dst, true);
                    run(out, s, dst, false);
                }
            }
        }
        System.out.println(out.toString());
    }

    private static void run(StringBuilder out, Sample s, String dst, boolean paSet) {
        Model m = new Model();
        m.srcVendor = s.vendor;
        m.dstVendor = dst;
        m.paSet = paSet;
        Parsers.parse(s.vendor, s.body, m);

        String fmt = "Palo Alto".equals(dst) ? (paSet ? "set" : "xml") : "-";
        out.append("@@CASE ").append(s.name).append(' ').append(dst)
                .append(" fmt=").append(fmt).append(" part=all\n");
        out.append(Emit.build(m).trim()).append('\n');
        out.append("@@END\n");

        String[] secs = Emit.sections(m);
        for (int i = 0; i < 4; i++) {
            out.append("@@CASE ").append(s.name).append(' ').append(dst)
                    .append(" fmt=").append(fmt).append(" part=").append(i).append('\n');
            out.append(secs[i] == null ? "" : secs[i].trim()).append('\n');
            out.append("@@END\n");
        }

        for (String n : m.notes) {
            out.append("@@NOTE ").append(s.name).append(' ').append(dst)
                    .append(" fmt=").append(fmt).append(' ').append(n).append('\n');
        }
    }
}
