# 网页版一致性维护

网页版由 `assets/fwtrans_web.html` 提供（APK 内置服务 + 独立交付的 `防火墙翻译-web.html` 都是它）。

## 唯一源文件

`fwtrans/assets/fwtrans_web.html`

独立网页、APK 内置页面都由它产出，不要单独手改 `防火墙翻译-web.html`。

## 每次发版前必跑

```bash
python3 fwtrans/tools/web_sync_check.py
```

做两件事：
1. 把 assets 里的网页导出成项目根目录的 `防火墙翻译-web.html`
2. 用 `tools/parity_samples.txt` 里的 6 份样例配置，跑 Java 版和网页 JS 版，
   逐字比对 6 个目标厂商 × 地址/服务/策略/NAT 四段 × PA set/XML 两种格式的输出与提示

输出 `✅ 网页版与 Java 版输出完全一致` 才算通过；有差异会打印 unified diff，以 java 为准修网页。

## 改了转换逻辑时

- 改 `Parsers.java` / `Emit.java` → 同步改 `assets/fwtrans_web.html` 里的 `parse*/emit*`，再跑上面命令
- 只改 App 界面（设置面板、OTA 等）→ 网页无需改动，但独立网页的 UI 若也要一致，按需同步
- 新增样例覆盖：往 `tools/parity_samples.txt` 里加 `### 名称 | 厂商` 开头的段落
