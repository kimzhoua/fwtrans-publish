#!/usr/bin/env python3
"""网页版一致性检查 + 独立网页导出。

唯一源文件：fwtrans/assets/fwtrans_web.html（打进 APK 的那份）
本脚本会：

1. 把它导出为项目目录下的 防火墙翻译-web.html（独立交付用的那份）
2. 用同一批样例配置，分别跑 Java 版（Parsers + Emit）和网页里的 JS 版，
   逐字比对 6 个目标厂商 × 4 段 × PA 两种格式的输出与提示清单
3. 有差异就打印出来并以退出码 1 结束

用法：python3 fwtrans/tools/web_sync_check.py [--no-export]
"""
import os
import re
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # fwtrans/
PROJ = os.path.dirname(ROOT)                                        # 项目根目录
ASSET = os.path.join(ROOT, "assets", "fwtrans_web.html")
EXPORT = os.path.join(PROJ, "防火墙翻译-web.html")
SAMPLES = os.path.join(ROOT, "tools", "parity_samples.txt")
SDK = "/home/user/toolchain/android-sdk"
JDK = "/home/user/toolchain/jdk-17.0.10+7"
TOOLS = os.path.join(ROOT, "tools")

HARNESS = r'''
const fs = require('fs');
const text = fs.readFileSync(process.argv[2], 'utf8');
const samples = []; let cur = null, body = [];
for (const raw of text.split('\n')) {
  if (raw.startsWith('### ')) {
    if (cur) { cur.body = body.join('\n'); samples.push(cur); body = []; }
    const parts = raw.slice(4).trim().split('|');
    cur = { name: parts[0].trim(), vendor: (parts[1] || '').trim() };
  } else if (cur) body.push(raw);
}
if (cur) { cur.body = body.join('\n'); samples.push(cur); }
const out = [];
for (const s of samples) {
  for (const dst of VENDORS) {
    const fmts = dst === 'Palo Alto' ? [true, false] : [true];
    for (const paSet of fmts) {
      const m = newModel(); m.srcVendor = s.vendor; m.dstVendor = dst; m.paSet = paSet;
      parse(s.vendor, s.body, m);
      const fmt = dst === 'Palo Alto' ? (paSet ? 'set' : 'xml') : '-';
      out.push(`@@CASE ${s.name} ${dst} fmt=${fmt} part=all`);
      out.push(emit(m, null).trim());
      out.push('@@END');
      const secs = sections(m);
      for (let i = 0; i < 4; i++) {
        out.push(`@@CASE ${s.name} ${dst} fmt=${fmt} part=${i}`);
        out.push((secs[i] || '').trim());
        out.push('@@END');
      }
      for (const n of m.notes) out.push(`@@NOTE ${s.name} ${dst} fmt=${fmt} ${n}`);
    }
  }
}
process.stdout.write(out.join('\n'));
'''


def export():
    src = open(ASSET, encoding="utf-8").read()
    open(EXPORT, "w", encoding="utf-8").write(src)
    print(f"已导出独立网页：{os.path.relpath(EXPORT, PROJ)}")


def js_logic():
    html = open(ASSET, encoding="utf-8").read()
    start = html.index("<script>") + len("<script>")
    end = html.index("/* =========================================================================\n   5. 界面")
    return html[start:end]


def run_node(tmp):
    js = os.path.join(tmp, "parity.js")
    open(js, "w", encoding="utf-8").write(js_logic() + HARNESS)
    r = subprocess.run(["node", js, SAMPLES], capture_output=True, text=True)
    if r.returncode != 0:
        print("node 运行失败：\n" + (r.stderr or "")[:3000])
        return None
    return r.stdout


def run_java(tmp):
    classes = os.path.join(tmp, "classes")
    os.makedirs(classes, exist_ok=True)
    cp = os.pathsep.join([
        os.path.join(SDK, "platforms", "android-34", "android.jar"),
    ])
    files = [os.path.join(ROOT, "src", "com", "example", "fwtrans", n)
             for n in ("Model.java", "Parsers.java", "Emit.java")]
    files.append(os.path.join(TOOLS, "ParityTest.java"))
    env = dict(os.environ, PATH=os.path.join(JDK, "bin") + os.pathsep + os.environ.get("PATH", ""))
    c = subprocess.run([os.path.join(JDK, "bin", "javac"), "-encoding", "UTF-8",
                        "-classpath", cp, "-d", classes] + files,
                       capture_output=True, text=True, env=env)
    if c.returncode != 0:
        print("javac 失败：\n" + (c.stderr or "")[:3000])
        return None
    r = subprocess.run([os.path.join(JDK, "bin", "java"), "-cp", classes,
                        "com.example.fwtrans.ParityTest", SAMPLES],
                       capture_output=True, text=True, env=env)
    if r.returncode != 0:
        print("java 运行失败：\n" + (r.stderr or "")[:3000])
        return None
    return r.stdout


def norm(text):
    lines = text.replace("\r\n", "\n").split("\n")
    while lines and lines[-1].strip() == "":
        lines.pop()
    return lines


def main():
    if "--no-export" not in sys.argv:
        export()

    tmp = tempfile.mkdtemp(prefix="fwpar-")
    java_out = run_java(tmp)
    js_out = run_node(tmp)
    if java_out is None or js_out is None:
        return 2

    a, b = norm(java_out), norm(js_out)
    if a == b:
        cases = sum(1 for l in a if l.startswith("@@CASE"))
        notes = sum(1 for l in a if l.startswith("@@NOTE"))
        print(f"✅ 网页版与 Java 版输出完全一致：{cases} 组用例，{notes} 条提示")
        return 0

    import difflib
    diff = list(difflib.unified_diff(a, b, fromfile="java", tofile="web", lineterm="", n=3))
    print("❌ 发现差异（java 为准，web 需对齐）：")
    for line in diff[:120]:
        print(line)
    if len(diff) > 120:
        print(f"... 共 {len(diff)} 行差异")
    return 1


if __name__ == "__main__":
    sys.exit(main())
