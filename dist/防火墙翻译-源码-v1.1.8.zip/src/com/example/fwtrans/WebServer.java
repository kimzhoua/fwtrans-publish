package com.example.fwtrans;

import android.content.Context;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.Enumeration;

/**
 * 内置的极简 HTTP 服务：把网页版界面（assets/fwtrans_web.html）提供给局域网内的设备。
 * 转换逻辑全部在对方浏览器里跑，服务只负责发一个 HTML 文件。
 */
public final class WebServer {

    private static final int[] PORTS = {8848, 8849, 8850, 8851, 8852};

    private static WebServer current;

    private ServerSocket server;
    private Thread acceptThread;
    private volatile boolean running;
    private volatile int port;
    private byte[] page;

    private WebServer() {
    }

    /** 已启动则返回当前实例，否则 null */
    public static synchronized WebServer current() {
        return (current != null && current.running) ? current : null;
    }

    public static boolean isRunning() {
        return current() != null;
    }

    /** 启动服务，返回实际端口；失败返回 -1 */
    public static synchronized int start(Context ctx) {
        WebServer running = current();
        if (running != null) return running.port;

        WebServer ws = new WebServer();
        try {
            InputStream in = ctx.getAssets().open("fwtrans_web.html");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            ws.page = bos.toByteArray();
        } catch (IOException e) {
            return -1;
        }

        for (int p : PORTS) {
            try {
                ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), p), 16);
                ws.server = ss;
                ws.port = p;
                break;
            } catch (IOException ignore) {
                // 端口被占用，换下一个
            }
        }
        if (ws.server == null) return -1;

        ws.running = true;
        ws.acceptThread = new Thread(new Runnable() {
            @Override
            public void run() {
                ws.loop();
            }
        }, "fwtrans-web");
        ws.acceptThread.setDaemon(true);
        ws.acceptThread.start();
        current = ws;
        return ws.port;
    }

    public static synchronized void stop() {
        WebServer ws = current;
        current = null;
        if (ws == null) return;
        ws.running = false;
        try {
            if (ws.server != null) ws.server.close();
        } catch (IOException ignore) {
        }
        ws.server = null;
    }

    /** 服务端口，未启动返回 0 */
    public static int port() {
        WebServer ws = current();
        return ws == null ? 0 : ws.port;
    }

    /** 局域网 IP，取不到返回 null */
    public static String localIp() {
        try {
            Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
            String fallback = null;
            for (NetworkInterface ni : Collections.list(nis)) {
                if (ni.isLoopback() || !ni.isUp()) continue;
                String name = ni.getName() == null ? "" : ni.getName().toLowerCase();
                for (InetAddress addr : Collections.list(ni.getInetAddresses())) {
                    if (!(addr instanceof Inet4Address)) continue;
                    if (addr.isLoopbackAddress()) continue;
                    String ip = addr.getHostAddress();
                    if (ip == null || ip.startsWith("127.")) continue;
                    if (name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("wifi")) {
                        return ip;
                    }
                    if (fallback == null) fallback = ip;
                }
            }
            return fallback;
        } catch (Exception e) {
            return null;
        }
    }

    /** 访问地址，例如 http://192.168.1.23:8848 */
    public static String url() {
        String ip = localIp();
        if (ip == null) return null;
        return "http://" + ip + ":" + port() + "/";
    }

    private void loop() {
        while (running) {
            Socket s = null;
            try {
                s = server.accept();
            } catch (IOException e) {
                break;
            }
            final Socket sock = s;
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    serve(sock);
                }
            }, "fwtrans-web-conn");
            t.setDaemon(true);
            t.start();
        }
    }

    private void serve(Socket s) {
        try {
            s.setSoTimeout(4000);
            InputStream in = s.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line = br.readLine();
            if (line == null) {
                s.close();
                return;
            }
            // 读到空行为止，忽略请求头
            String h;
            while ((h = br.readLine()) != null && h.length() > 0) {
                // skip headers
            }

            String[] parts = line.split(" ");
            String method = parts.length > 0 ? parts[0] : "GET";
            String path = parts.length > 1 ? parts[1] : "/";
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            try {
                path = URLDecoder.decode(path, "UTF-8");
            } catch (Exception ignore) {
            }

            if ("/favicon.ico".equals(path)) {
                write(s, "204 No Content", "text/plain", new byte[0], false);
                return;
            }
            boolean ok = "/".equals(path) || "/index.html".equals(path)
                    || "/fwtrans.html".equals(path) || "/fwtrans".equals(path);
            if (ok) {
                write(s, "200 OK", "text/html; charset=utf-8", page, "HEAD".equals(method));
            } else {
                byte[] msg = ("未找到：" + path + "\n访问 http://手机IP:" + port + "/ 即可")
                        .getBytes("UTF-8");
                write(s, "404 Not Found", "text/plain; charset=utf-8", msg, "HEAD".equals(method));
            }
        } catch (Exception ignore) {
            // 客户端断开等，忽略
        } finally {
            try {
                s.close();
            } catch (IOException ignore) {
            }
        }
    }

    private void write(Socket s, String status, String type, byte[] body, boolean headOnly) {
        try {
            OutputStream out = s.getOutputStream();
            StringBuilder sb = new StringBuilder();
            sb.append("HTTP/1.1 ").append(status).append("\r\n");
            sb.append("Content-Type: ").append(type).append("\r\n");
            sb.append("Content-Length: ").append(body.length).append("\r\n");
            sb.append("Cache-Control: no-store\r\n");
            sb.append("Connection: close\r\n\r\n");
            out.write(sb.toString().getBytes("UTF-8"));
            if (!headOnly) out.write(body);
            out.flush();
        } catch (IOException ignore) {
        }
    }
}
