package com.example.fwtrans;

import java.util.ArrayList;
import java.util.List;

/** 统一中间模型：地址、服务、策略、NAT */
final class Model {

    static class Addr {
        String name;
        String type = "net";     // net | range | fqdn
        String ip;               // net 起始地址
        int prefix = 32;
        String ip2;              // range 结束地址
        String fqdn;

        String show() {
            if ("fqdn".equals(type)) return fqdn + " (域名)";
            if ("range".equals(type)) return ip + " ~ " + ip2;
            return ip + "/" + prefix;
        }
    }

    static class Svc {
        String name;
        String proto = "tcp";    // tcp | udp | icmp | any
        String port = "";        // 80 或 80-90

        String show() {
            if ("any".equals(proto)) return "any";
            if (port == null || port.length() == 0) return proto;
            return proto + "/" + port;
        }
    }

    static class Pol {
        String name;
        String from = "";
        String to = "";
        List<String> src = new ArrayList<>();
        List<String> dst = new ArrayList<>();
        List<String> svc = new ArrayList<>();
        String action = "permit";

        boolean isDeny() {
            return "deny".equals(action) || "drop".equals(action) || "block".equals(action);
        }
    }

    static class Snat {
        String name;
        String src = "any";
        String dst = "any";
        String svc = "any";
        String toIp;
    }

    static class Dnat {
        String name;
        String proto = "tcp";
        String extIp;
        String extPort = "";
        String intIp;
        String intPort = "";
    }

    List<Addr> addrs = new ArrayList<>();
    List<Svc> svcs = new ArrayList<>();
    List<Pol> pols = new ArrayList<>();
    List<Snat> snats = new ArrayList<>();
    List<Dnat> dnats = new ArrayList<>();
    List<String> notes = new ArrayList<>();
    java.util.Map<String, List<String>> addrGroups = new java.util.HashMap<>();
    java.util.Map<String, List<String>> svcGroups = new java.util.HashMap<>();
    boolean paSet = true;    // PA 目标：true=set 命令，false=XML
    String srcVendor = "";
    String dstVendor = "";
    String srcName = "";

    // ---------- 查找 / 去重 ----------
    Addr addr(String name) {
        for (Addr a : addrs) if (a.name.equalsIgnoreCase(name)) return a;
        return null;
    }

    Svc svc(String name) {
        for (Svc s : svcs) if (s.name.equalsIgnoreCase(name)) return s;
        return null;
    }

    String addAddr(Addr a) {
        Addr o = addr(a.name);
        if (o != null) return o.name;
        addrs.add(a);
        return a.name;
    }

    String addSvc(Svc s) {
        Svc o = svc(s.name);
        if (o != null) return o.name;
        svcs.add(s);
        return s.name;
    }

    /** 内联地址（策略里直接写 IP）→ 自动生成一个对象名 */
    String ensureAddr(String ip, int prefix) {
        for (Addr a : addrs) {
            if ("net".equals(a.type) && a.ip != null && a.ip.equals(ip) && a.prefix == prefix)
                return a.name;
        }
        String nm = "a_" + ip.replace('.', '_') + "_" + prefix;
        Addr ex = addr(nm);
        if (ex != null) return ex.name;
        Addr a = new Addr();
        a.name = nm;
        a.type = "net";
        a.ip = ip;
        a.prefix = prefix;
        addrs.add(a);
        return nm;
    }

    String ensureSvc(String proto, String port) {
        for (Svc s : svcs) {
            if (s.proto != null && s.proto.equals(proto)
                    && s.port != null && s.port.equals(port)) return s.name;
        }
        String nm = "s_" + proto + "_" + port.replace("-", "_");
        Svc ex = svc(nm);
        if (ex != null) return ex.name;
        Svc s = new Svc();
        s.name = nm;
        s.proto = proto;
        s.port = port;
        svcs.add(s);
        return nm;
    }

    void note(String s) {
        if (s != null && s.length() > 0 && !notes.contains(s)) notes.add(s);
    }

    // ---------- 工具 ----------
    static boolean isIp(String s) {
        if (s == null) return false;
        String[] p = s.split("\\.");
        if (p.length != 4) return false;
        for (String x : p) {
            try {
                int v = Integer.parseInt(x);
                if (v < 0 || v > 255) return false;
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    static int maskToPrefix(String mask) {
        if (mask == null) return 32;
        if (!mask.contains(".")) {
            try {
                return Math.min(32, Math.max(0, Integer.parseInt(mask.replace("/", ""))));
            } catch (Exception e) {
                return 32;
            }
        }
        if (!isIp(mask)) return 32;
        int bits = 0;
        boolean zero = false;
        for (String part : mask.split("\\.")) {
            int v = Integer.parseInt(part);
            for (int i = 7; i >= 0; i--) {
                if (((v >> i) & 1) == 1) {
                    if (zero) return bits;
                    bits++;
                } else {
                    zero = true;
                }
            }
        }
        return bits;
    }

    static String prefixToMask(int p) {
        int[] out = new int[4];
        for (int i = 0; i < 4; i++) {
            int bits = Math.min(8, Math.max(0, p - i * 8));
            out[i] = bits == 0 ? 0 : (0xFF << (8 - bits)) & 0xFF;
        }
        return out[0] + "." + out[1] + "." + out[2] + "." + out[3];
    }
}
