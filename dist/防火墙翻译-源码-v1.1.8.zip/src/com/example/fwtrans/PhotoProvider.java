package com.example.fwtrans;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;

/** 把项目里的照片以 content:// 形式临时授给外部应用（分享用） */
public class PhotoProvider extends ContentProvider {

    static final String AUTHORITY = "com.example.fwtrans.fileprovider";

    static Uri uriFor(File f) {
        return Uri.parse("content://" + AUTHORITY + f.getAbsolutePath());
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws java.io.FileNotFoundException {
        File f = new File(uri.getPath());
        // 系统相机需要用「写」模式把照片写到我们给的文件里
        if (mode != null && mode.contains("w")) {
            if (!f.getParentFile().exists()) f.getParentFile().mkdirs();
            // 有些厂商相机用 rw 打开后还会回头 stat，用只写会失败，这里给读写
            return ParcelFileDescriptor.open(f,
                    ParcelFileDescriptor.MODE_READ_WRITE
                            | ParcelFileDescriptor.MODE_CREATE
                            | ParcelFileDescriptor.MODE_TRUNCATE);
        }
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        // 安装包也要通过这个 provider 交给安装器
        if (uri.getPath() != null && uri.getPath().endsWith(".apk")) {
            return "application/vnd.android.package-archive";
        }
        return "image/jpeg";
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        // 系统相机（尤其 Google/三星系）会查 DISPLAY_NAME 和 SIZE，返回 null 会被当成写入失败
        File f = new File(uri.getPath());
        android.database.MatrixCursor c = new android.database.MatrixCursor(
                new String[]{
                        android.provider.OpenableColumns.DISPLAY_NAME,
                        android.provider.OpenableColumns.SIZE,
                        "_data"});
        c.addRow(new Object[]{f.getName(), f.exists() ? f.length() : 0, f.getAbsolutePath()});
        return c;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
