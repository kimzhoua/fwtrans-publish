package com.example.fwtrans;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 各家配置解析：把文本转成统一模型 */
final class Parsers {

    private static String[] tok(String line) {
        return line.trim().split("\\s+");
    }

    private static String unq(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    static void parse(String vendor, String text, Model m) {
        switch (vendor) {
            case "华为 USG":
                huawei(text, m);
                break;
            case "华三 H3C":
                h3c(text, m);
                break;
            case "飞塔 Fortinet":
                forti(text, m);
                break;
            case "山石 Hillstone":
                hillstone(text, m);
                break;
            case "Palo Alto":
                pa(text, m);
                break;
            case "Cisco ASA":
                asa(text, m);
                break;
            default:
                m.note("未知源厂商：" + vendor);
        }
    }

    // ================= 华为 USG =================
    private static void huawei(String text, Model m) {
        String addrSet = null;
        String svcSet = null;
        Model.Pol cur = null;

        for (String raw : text.split("\n")) {
            String l = raw.replace("\t", " ").trim();
            if (l.length() == 0 || l.startsWith("#") || l.startsWith("!")) continue;
            String low = l.toLowerCase();
            String[] t = tok(l);

            if (low.startsWith("ip address-set ") && low.contains("type object")) {
                addrSet = t[2];
                svcSet = null;
                cur = null;
                continue;
            }
            if (low.startsWith("ip service-set ") && low.contains("type object")) {
                svcSet = t[2];
                addrSet = null;
                cur = null;
                continue;
            }
            if (low.equals("security-policy") || low.startsWith("security-policy ")) {
                addrSet = null;
                svcSet = null;
                cur = null;
                continue;
            }

            // 地址对象条目
            if (addrSet != null && low.startsWith("address ") && t.length >= 3
                    && Character.isDigit(t[1].charAt(0))) {
                String ip = t[2];
                if (!Model.isIp(ip)) {
                    addrSet = null;
                    continue;
                }
                Model.Addr a = new Model.Addr();
                a.name = addrSet + "_" + t[1];
                a.type = "net";
                a.ip = ip;
                if (t.length >= 5 && t[3].equalsIgnoreCase("mask")) {
                    a.prefix = Model.maskToPrefix(t[4]);
                } else if (t.length >= 4 && (Model.isIp(t[3]) || t[3].matches("\\d+"))) {
                    a.prefix = Model.maskToPrefix(t[3]);
                } else {
                    a.prefix = 32;
                }
                m.addrs.add(a);
                List<String> g = m.addrGroups.get(addrSet);
                if (g == null) {
                    g = new ArrayList<>();
                    m.addrGroups.put(addrSet, g);
                }
                g.add(a.name);
                continue;
            }
            // 服务对象条目
            if (svcSet != null && low.startsWith("service ") && t.length >= 4
                    && Character.isDigit(t[1].charAt(0))) {
                String proto = t[2].toLowerCase();
                String p1 = t[3];
                String p2 = t.length >= 5 ? t[4] : p1;
                Model.Svc s = new Model.Svc();
                s.name = svcSet + "_" + t[1];
                s.proto = proto;
                s.port = (p1.equals(p2) ? p1 : p1 + "-" + p2);
                m.svcs.add(s);
                List<String> g2 = m.svcGroups.get(svcSet);
                if (g2 == null) {
                    g2 = new ArrayList<>();
                    m.svcGroups.put(svcSet, g2);
                }
                g2.add(s.name);
                continue;
            }

            // 策略规则
            if (low.startsWith("rule name ")) {
                Model.Pol p = new Model.Pol();
                p.name = l.substring("rule name ".length()).trim();
                if (p.name.startsWith("\"")) p.name = unq(p.name);
                m.pols.add(p);
                cur = p;
                continue;
            }
            if (cur != null) {
                if (low.startsWith("source-zone ")) {
                    cur.from = l.substring("source-zone ".length()).trim();
                    continue;
                }
                if (low.startsWith("destination-zone ")) {
                    cur.to = l.substring("destination-zone ".length()).trim();
                    continue;
                }
                if (low.startsWith("source-address ")) {
                    addRef(m, cur.src, l.substring("source-address ".length()).trim(), true);
                    continue;
                }
                if (low.startsWith("destination-address ")) {
                    addRef(m, cur.dst, l.substring("destination-address ".length()).trim(), false);
                    continue;
                }
                if (low.startsWith("service ")) {
                    String v = l.substring("service ".length()).trim();
                    String nm = v.replace("service-set ", "").trim();
                    List<String> g = m.svcGroups.get(nm);
                    if (g != null) cur.svc.addAll(g);
                    else cur.svc.add(nm);
                    continue;
                }
                if (low.startsWith("action ")) {
                    String a = l.substring("action ".length()).trim();
                    cur.action = a.startsWith("permit") ? "permit" : "deny";
                    continue;
                }
            }

            // NAT：nat static global x inside y
            if (low.startsWith("nat static global ")) {
                String[] parts = l.split("\\s+");
                Model.Dnat d = new Model.Dnat();
                d.name = "dnat_" + m.dnats.size();
                for (int i = 0; i < parts.length; i++) {
                    if ("global".equalsIgnoreCase(parts[i]) && i + 1 < parts.length)
                        d.extIp = parts[i + 1];
                    if ("inside".equalsIgnoreCase(parts[i]) && i + 1 < parts.length)
                        d.intIp = parts[i + 1];
                }
                if (d.extIp != null && d.intIp != null) m.dnats.add(d);
                continue;
            }
            if (low.startsWith("nat outbound")) {
                m.note("华为 nat outbound（源NAT 规则）未转换：" + l);
            }
        }
        if (m.pols.isEmpty() && addrSet != null) m.note("未识别到安全策略段");
    }

    private static void groupAdd(java.util.Map<String, List<String>> map, String key, String member) {
        List<String> g = map.get(key);
        if (g == null) {
            g = new ArrayList<>();
            map.put(key, g);
        }
        g.add(member);
    }

    private static void addRef(Model m, List<String> list, String v, boolean src) {
        v = v.trim();
        if (v.length() == 0) return;
        v = v.replace("address-set ", "").replace("address-group ", "").trim();
        String[] t = v.split("\\s+");
        if (Model.isIp(t[0])) {
            int prefix = 32;
            if (t.length >= 3 && t[1].equalsIgnoreCase("mask")) prefix = Model.maskToPrefix(t[2]);
            else if (t.length >= 2) prefix = Model.maskToPrefix(t[1]);
            list.add(m.ensureAddr(t[0], prefix));
        } else {
            List<String> g = m.addrGroups.get(t[0]);
            if (g != null) list.addAll(g);
            else list.add(t[0]);
        }
    }

    // ================= 华三 H3C =================
    private static void h3c(String text, Model m) {
        String addrGroup = null;
        String svcGroup = null;
        String svcProto = "";
        Model.Pol cur = null;

        for (String raw : text.split("\n")) {
            String l = raw.replace("\t", " ").trim();
            if (l.length() == 0 || l.startsWith("#") || l.startsWith("!")) continue;
            String low = l.toLowerCase();
            String[] t = tok(l);
            // H3C 对象组成员带序号： " 0 network-subnet 10.0.0.0 24"
            if (t.length >= 2 && t[0].matches("\\d+")) {
                l = l.substring(l.indexOf(t[1]));
                low = l.toLowerCase();
                t = tok(l);
            }

            if (low.startsWith("object-group ip address ")) {
                addrGroup = t.length >= 4 ? t[3] : t[2];
                svcGroup = null;
                svcProto = "";
                cur = null;
                continue;
            }
            if (low.startsWith("object-group service ")) {
                svcGroup = t[2];
                svcProto = t.length >= 4 ? t[3].toLowerCase() : "";
                addrGroup = null;
                cur = null;
                continue;
            }
            if (low.startsWith("security-policy")) {
                addrGroup = null;
                svcGroup = null;
                cur = null;
                continue;
            }

            if (addrGroup != null) {
                // H3C 各版本写法不同：network-subnet / network / subnet / host-address / network-range
                String kind = t[0].toLowerCase();
                boolean isNet = kind.equals("network-subnet") || kind.equals("network")
                        || kind.equals("subnet") || kind.equals("ip-address");
                boolean isHost = kind.equals("host-address") || kind.equals("host");
                boolean isRange = kind.equals("network-range") || kind.equals("range");
                if ((isNet && t.length >= 3) || (isHost && t.length >= 2) || (isRange && t.length >= 3)) {
                    Model.Addr a = new Model.Addr();
                    a.name = addrGroup + "_" + (m.addrs.size());
                    a.ip = t[1];
                    if (isRange) {
                        a.type = "range";
                        a.ip2 = t[2];
                    } else if (isHost) {
                        a.type = "net";
                        a.prefix = 32;
                    } else {
                        a.type = "net";
                        String mask = t[2];
                        if (mask.equalsIgnoreCase("mask") && t.length >= 4) mask = t[3];
                        a.prefix = Model.maskToPrefix(mask);
                    }
                    m.addrs.add(a);
                    groupAdd(m.addrGroups, addrGroup, a.name);
                    continue;
                }
            }

            if (svcGroup != null) {
                String proto = svcProto;
                String port = null;
                if (low.startsWith("tcp ") || low.startsWith("udp ")) {
                    proto = t[0].toLowerCase();
                    port = h3cPort(t, 1);
                } else if (low.startsWith("port eq ")) {
                    port = t.length >= 3 ? t[2] : null;
                } else if (low.startsWith("port range ")) {
                    port = t.length >= 4 ? t[2] + "-" + t[3] : null;
                } else if (low.startsWith("destination eq ")) {
                    port = t.length >= 3 ? t[2] : null;
                } else if (low.startsWith("destination range ")) {
                    port = t.length >= 4 ? t[2] + "-" + t[3] : null;
                }
                if (!proto.isEmpty() && port != null && port.length() > 0) {
                    Model.Svc sv = new Model.Svc();
                    sv.name = svcGroup + "_" + m.svcs.size();
                    sv.proto = proto;
                    sv.port = port;
                    m.svcs.add(sv);
                    groupAdd(m.svcGroups, svcGroup, sv.name);
                }
                continue;
            }

            if (low.startsWith("rule name ")) {
                Model.Pol p = new Model.Pol();
                p.name = unq(l.substring("rule name ".length()).trim());
                m.pols.add(p);
                cur = p;
                continue;
            }
            if (cur != null) {
                if (low.startsWith("source-zone ")) {
                    cur.from = l.substring("source-zone ".length()).trim();
                    continue;
                }
                if (low.startsWith("destination-zone ")) {
                    cur.to = l.substring("destination-zone ".length()).trim();
                    continue;
                }
                if (low.startsWith("source-ip ")) {
                    addRef(m, cur.src, l.substring("source-ip ".length()), true);
                    continue;
                }
                if (low.startsWith("destination-ip ")) {
                    addRef(m, cur.dst, l.substring("destination-ip ".length()), false);
                    continue;
                }
                if (low.startsWith("service ")) {
                    String nm = unq(l.substring("service ".length()).trim());
                    List<String> g = m.svcGroups.get(nm);
                    if (g != null) cur.svc.addAll(g);
                    else cur.svc.add(nm);
                    continue;
                }
                if (low.startsWith("action ")) {
                    String a = l.substring("action ".length()).trim();
                    cur.action = a.startsWith("pass") || a.startsWith("permit") ? "permit" : "deny";
                    continue;
                }
            }

            // nat server protocol tcp global 1.1.1.1 80 inside 192.168.1.10 80
            if (low.startsWith("nat server ")) {
                Model.Dnat d = new Model.Dnat();
                d.name = "dnat_" + m.dnats.size();
                Matcher mm = Pattern.compile(
                        "protocol\\s+(tcp|udp)\\s+global\\s+([0-9.]+)\\s*(\\d+)?\\s+inside\\s+([0-9.]+)\\s*(\\d+)?",
                        Pattern.CASE_INSENSITIVE).matcher(l);
                if (mm.find()) {
                    d.proto = mm.group(1).toLowerCase();
                    d.extIp = mm.group(2);
                    d.extPort = mm.group(3) == null ? "" : mm.group(3);
                    d.intIp = mm.group(4);
                    d.intPort = mm.group(5) == null ? d.extPort : mm.group(5);
                    m.dnats.add(d);
                }
                continue;
            }
            if (low.startsWith("nat outbound")) {
                m.note("华三 nat outbound（源NAT）未转换：" + l);
            }
        }
    }

    /** 华三服务端口：t[start] 或 t[start] t[start+1]（相同则单端口，否则区间） */
    private static String h3cPort(String[] t, int start) {
        if (t.length <= start) return "";
        String p1 = t[start];
        String p2 = t.length > start + 1 ? t[start + 1] : p1;
        if (!p1.matches("\\d+(-\\d+)?")) return "";
        if (p1.equalsIgnoreCase(p2)) return p1;
        if (!p2.matches("\\d+")) return p1;
        return p1 + "-" + p2;
    }


    // ================= 飞塔 Fortinet =================
    private static void forti(String text, Model m) {
        String section = "";
        String curName = null;
        Model.Addr a = null;
        Model.Svc s = null;
        Model.Pol p = null;
        Model.Dnat d = null;
        String poolStart = null;

        for (String raw : text.split("\n")) {
            String l = raw.trim();
            if (l.length() == 0 || l.startsWith("#")) continue;
            String low = l.toLowerCase();

            if (low.startsWith("config firewall address")) {
                section = "addr";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall service custom")) {
                section = "svc";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall policy")) {
                section = "pol";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall vip")) {
                section = "vip";
                curName = null;
                continue;
            }
            if (low.startsWith("config firewall ippool")) {
                section = "ippool";
                curName = null;
                continue;
            }
            if (low.startsWith("config ") || low.equals("end")) {
                section = "";
                curName = null;
                continue;
            }

            if (low.startsWith("edit ")) {
                curName = unq(l.substring(5));
                a = null;
                s = null;
                p = null;
                d = null;
                if ("addr".equals(section)) {
                    a = new Model.Addr();
                    a.name = curName;
                    m.addrs.add(a);
                } else if ("svc".equals(section)) {
                    s = new Model.Svc();
                    s.name = curName;
                    m.svcs.add(s);
                } else if ("pol".equals(section)) {
                    p = new Model.Pol();
                    p.name = curName;
                    m.pols.add(p);
                } else if ("vip".equals(section)) {
                    d = new Model.Dnat();
                    d.name = curName;
                }
                continue;
            }

            if (low.startsWith("set ")) {
                String body = l.substring(4).trim();
                String key = body.split("\\s+")[0].toLowerCase();
                String val = body.substring(body.indexOf(key) + key.length()).trim();
                if ("addr".equals(section) && a != null) {
                    if (key.equals("subnet")) {
                        String[] t = val.split("\\s+");
                        a.type = "net";
                        a.ip = t[0];
                        a.prefix = Model.maskToPrefix(t.length > 1 ? t[1] : "32");
                    } else if (key.equals("type") && val.contains("fqdn")) {
                        a.type = "fqdn";
                    } else if (key.equals("fqdn")) {
                        a.fqdn = unq(val);
                        a.type = "fqdn";
                    } else if (key.equals("start-ip")) {
                        a.ip = unq(val);
                    } else if (key.equals("end-ip")) {
                        a.type = "range";
                        a.ip2 = unq(val);
                    }
                } else if ("svc".equals(section) && s != null) {
                    if (key.equals("tcp-portrange")) {
                        s.proto = "tcp";
                        s.port = portRange(unq(val));
                    } else if (key.equals("udp-portrange")) {
                        s.proto = "udp";
                        s.port = portRange(unq(val));
                    } else if (key.equals("protocol")) {
                        String v2 = unq(val).toUpperCase();
                        if (v2.contains("ICMP")) {
                            s.proto = "icmp";
                            s.port = "";
                        } else if (v2.contains("TCP")) {
                            s.proto = "tcp";
                        } else if (v2.contains("UDP")) {
                            s.proto = "udp";
                        }
                    }
                } else if ("pol".equals(section) && p != null) {
                    if (key.equals("name")) p.name = unq(val);
                    else if (key.equals("srcintf")) p.from = unq(val);
                    else if (key.equals("dstintf")) p.to = unq(val);
                    else if (key.equals("srcaddr")) addAll(m, p.src, val, true);
                    else if (key.equals("dstaddr")) addAll(m, p.dst, val, false);
                    else if (key.equals("service")) addAllSvc(p.svc, val);
                    else if (key.equals("action")) p.action = val.contains("accept") ? "permit" : "deny";
                    else if (key.equals("nat") && val.contains("enable"))
                        m.note("飞塔策略 " + p.name + " 开启了 NAT（需在目标侧手工确认源NAT 地址）");
                } else if ("vip".equals(section) && d != null) {
                    if (key.equals("extip")) d.extIp = unq(val);
                    else if (key.equals("mappedip")) d.intIp = unq(val);
                    else if (key.equals("extport")) d.extPort = unq(val);
                    else if (key.equals("mappedport")) d.intPort = unq(val);
                    else if (key.equals("protocol")) d.proto = unq(val).toLowerCase();
                } else if ("ippool".equals(section)) {
                    if (key.equals("startip")) poolStart = unq(val);
                }
            }
            if (low.equals("next")) {
                if ("vip".equals(section) && d != null && d.extIp != null && d.intIp != null) {
                    Model.Dnat dd = d;
                    m.dnats.add(dd);
                    d = null;
                }
                if ("ippool".equals(section) && poolStart != null) {
                    Model.Snat sn = new Model.Snat();
                    sn.name = curName;
                    sn.toIp = poolStart;
                    m.snats.add(sn);
                    m.note("飞塔 ippool " + curName + " 已转为源NAT 地址池，需要在目标防火墙策略里绑定");
                    poolStart = null;
                }
                curName = null;
            }
        }
    }

    private static String portRange(String v) {
        // "80" 或 "80-90" 或 "80 90" 或 "80-90 100-110"
        v = v.trim();
        String first = v.split("\\s+")[0];
        return first.replace(":", "-");
    }

    private static void addAll(Model m, List<String> list, String val, boolean src) {
        Matcher q = Pattern.compile("\"([^\"]+)\"").matcher(val);
        List<String> names = new ArrayList<>();
        while (q.find()) names.add(q.group(1));
        if (names.isEmpty()) names.add(unq(val));
        for (String n : names) {
            if (n.equalsIgnoreCase("all") || n.equalsIgnoreCase("any")) {
                list.add("any");
            } else if (Model.isIp(n)) {
                list.add(m.ensureAddr(n, 32));
            } else {
                list.add(n);
            }
        }
    }

    private static void addAllSvc(List<String> list, String val) {
        Matcher q = Pattern.compile("\"([^\"]+)\"").matcher(val);
        boolean any = false;
        while (q.find()) {
            String n = q.group(1);
            if (n.equalsIgnoreCase("ALL") || n.equalsIgnoreCase("any")) any = true;
            else list.add(n);
        }
        if (list.isEmpty() && !any) {
            String n = unq(val);
            if (n.equalsIgnoreCase("ALL") || n.equalsIgnoreCase("any")) any = true;
            else list.add(n);
        }
        if (any) list.add(0, "any");
    }

    // ================= 山石 Hillstone =================
    private static void hillstone(String text, Model m) {
        Model.Pol cur = null;
        Model.Snat sn = null;

        for (String raw : text.split("\n")) {
            String l = raw.trim();
            if (l.length() == 0 || l.startsWith("#") || l.startsWith("!")) continue;
            String low = l.toLowerCase();

            if (low.startsWith("address ") || low.startsWith("ip address ")) {
                String body = l.substring(low.indexOf("address ") + 8).trim();
                String[] t = tok(body);
                if (t.length < 2) continue;
                String name = unq(t[0]);
                Model.Addr a = new Model.Addr();
                a.name = name;
                String v = unq(t[1]);
                if (v.contains("/")) {
                    String[] sp = v.split("/");
                    a.ip = sp[0];
                    a.prefix = Model.maskToPrefix(sp[1]);
                } else if (Model.isIp(v)) {
                    if (t.length >= 3 && Model.isIp(unq(t[2]))) {
                        a.type = "range";
                        a.ip = v;
                        a.ip2 = unq(t[2]);
                    } else {
                        a.ip = v;
                        a.prefix = 32;
                    }
                } else {
                    a.type = "fqdn";
                    a.fqdn = v;
                }
                m.addrs.add(a);
                continue;
            }

            if (low.startsWith("service ")) {
                String body = l.substring(8).trim();
                String[] t = tok(body);
                String name = unq(t[0]);
                Model.Svc s = new Model.Svc();
                s.name = name;
                if (t.length >= 2) {
                    String proto = unq(t[1]).toLowerCase();
                    s.proto = proto.equals("icmp") ? "icmp" : proto;
                    if (t.length >= 4) {
                        String p1 = t[2];
                        String p2 = t[3];
                        s.port = p1.equals(p2) ? p1 : p1 + "-" + p2;
                    } else if (t.length >= 3) {
                        s.port = t[2];
                    }
                }
                m.svcs.add(s);
                continue;
            }

            if (low.startsWith("rule id ") || low.startsWith("rule name ")) {
                Model.Pol p = new Model.Pol();
                p.name = "rule_" + m.pols.size();
                Matcher nm = Pattern.compile("name\\s+\"([^\"]+)\"").matcher(l);
                if (nm.find()) p.name = nm.group(1);
                m.pols.add(p);
                cur = p;
                continue;
            }
            if (cur != null) {
                if (low.startsWith("from ") && low.contains(" to ")) {
                    Matcher mt = Pattern.compile("from\\s+\"?([^\\s\"]+)\"?\\s+to\\s+\"?([^\\s\"]+)\"?",
                            Pattern.CASE_INSENSITIVE).matcher(l);
                    if (mt.find()) {
                        cur.from = mt.group(1);
                        cur.to = mt.group(2);
                    }
                    continue;
                }
                if (low.startsWith("match ")) {
                    Matcher src = Pattern.compile("src-ip\\s+\"?([^\\s\"]+)\"?", Pattern.CASE_INSENSITIVE).matcher(l);
                    if (src.find()) addName(m, cur.src, src.group(1));
                    Matcher dst = Pattern.compile("dst-ip\\s+\"?([^\\s\"]+)\"?", Pattern.CASE_INSENSITIVE).matcher(l);
                    if (dst.find()) addName(m, cur.dst, dst.group(1));
                    Matcher sv = Pattern.compile("service\\s+\"?([^\\s\"]+)\"?", Pattern.CASE_INSENSITIVE).matcher(l);
                    if (sv.find()) cur.svc.add(sv.group(1));
                    continue;
                }
                if (low.startsWith("action ")) {
                    String act = l.substring(7).trim().toLowerCase();
                    cur.action = act.startsWith("permit") || act.startsWith("accept") ? "permit" : "deny";
                    continue;
                }
            }

            if (low.startsWith("nat ") || low.startsWith("snat")) {
                sn = new Model.Snat();
                sn.name = "snat_" + m.snats.size();
                Matcher t = Pattern.compile("src-ip\\s+\"?([^\\s\"]+)\"?", Pattern.CASE_INSENSITIVE).matcher(l);
                if (t.find()) sn.src = t.group(1);
                Matcher tr = Pattern.compile("translate\\s+src-ip\\s+\"?([^\\s\"]+)\"?", Pattern.CASE_INSENSITIVE).matcher(l);
                if (tr.find()) {
                    sn.toIp = tr.group(1);
                    m.snats.add(sn);
                }
                continue;
            }
        }
    }

    private static void addName(Model m, List<String> list, String n) {
        if (n == null) return;
        if (n.equalsIgnoreCase("any") || n.equalsIgnoreCase("all")) list.add("any");
        else if (Model.isIp(n)) list.add(m.ensureAddr(n, 32));
        else list.add(n);
    }

    // ================= Palo Alto（XML） =================
    private static void pa(String text, Model m) {
        String addrRegion = region(text, "<address>", "</address>");
        Matcher e = Pattern.compile("<entry\\s+name=\"([^\"]+)\"[^>]*>(.*?)</entry>",
                Pattern.DOTALL).matcher(addrRegion);
        while (e.find()) {
            Model.Addr a = new Model.Addr();
            a.name = e.group(1);
            String b = e.group(2);
            Matcher net = Pattern.compile("<ip-netmask>([^<]+)</ip-netmask>").matcher(b);
            Matcher host = Pattern.compile("<ip-address>([^<]+)</ip-address>").matcher(b);
            Matcher rng = Pattern.compile("<ip-range>([^<]+)</ip-range>").matcher(b);
            Matcher fq = Pattern.compile("<fqdn>([^<]+)</fqdn>").matcher(b);
            if (net.find()) {
                String v = net.group(1).trim();
                if (v.contains("/")) {
                    a.ip = v.split("/")[0];
                    a.prefix = Model.maskToPrefix(v.split("/")[1]);
                } else {
                    a.ip = v;
                    a.prefix = 32;
                }
            } else if (host.find()) {
                a.ip = host.group(1).trim();
                a.prefix = 32;
            } else if (rng.find()) {
                String[] sp = rng.group(1).trim().split("-");
                a.type = "range";
                a.ip = sp[0].trim();
                a.ip2 = sp.length > 1 ? sp[1].trim() : sp[0].trim();
            } else if (fq.find()) {
                a.type = "fqdn";
                a.fqdn = fq.group(1).trim();
            } else {
                continue;
            }
            m.addrs.add(a);
        }

        String svcRegion = region(text, "<service>", "</service>");
        Matcher se = Pattern.compile("<entry\\s+name=\"([^\"]+)\"[^>]*>(.*?)</entry>",
                Pattern.DOTALL).matcher(svcRegion);
        while (se.find()) {
            Model.Svc s = new Model.Svc();
            s.name = se.group(1);
            String b = se.group(2);
            if (b.contains("<tcp>")) s.proto = "tcp";
            else if (b.contains("<udp>")) s.proto = "udp";
            Matcher pt = Pattern.compile("<port>([^<]+)</port>").matcher(b);
            if (pt.find()) s.port = pt.group(1).trim();
            m.svcs.add(s);
        }

        String rulesRegion = region(text, "<rules>", "</rules>");
        Matcher re = Pattern.compile("<entry\\s+name=\"([^\"]+)\"[^>]*>(.*?)</entry>",
                Pattern.DOTALL).matcher(rulesRegion);
        while (re.find()) {
            String b = re.group(2);
            if (b.contains("<disabled>yes</disabled>")) continue;
            Model.Pol p = new Model.Pol();
            p.name = re.group(1);
            p.from = firstMember(b, "from");
            p.to = firstMember(b, "to");
            p.src.addAll(members(b, "source"));
            p.dst.addAll(members(b, "destination"));
            p.svc.addAll(members(b, "service"));
            Matcher ac = Pattern.compile("<action>([^<]+)</action>").matcher(b);
            if (ac.find()) p.action = ac.group(1).trim().contains("allow") ? "permit" : "deny";
            if (p.src.isEmpty()) p.src.add("any");
            if (p.dst.isEmpty()) p.dst.add("any");
            if (p.svc.isEmpty()) p.svc.add("any");
            m.pols.add(p);
        }

        // NAT：source-translation / destination-translation
        Matcher dn = Pattern.compile(
                "<destination-translation>(.*?)</destination-translation>", Pattern.DOTALL)
                .matcher(text);
        while (dn.find()) {
            Model.Dnat d = new Model.Dnat();
            d.name = "dnat_" + m.dnats.size();
            String b = dn.group(1);
            Matcher ip = Pattern.compile("<translated-address>\\s*<member>([^<]+)</member>",
                    Pattern.DOTALL).matcher(b);
            if (ip.find()) d.intIp = ip.group(1).trim();
            Matcher pt = Pattern.compile("<translated-port>([^<]+)</translated-port>").matcher(b);
            if (pt.find()) d.intPort = pt.group(1).trim();
            if (d.intIp != null) {
                d.extIp = d.intIp;
                m.dnats.add(d);
                m.note("Palo Alto 目的NAT 规则缺少公网地址映射信息，请在目标侧核对 extIp/extPort");
            }
        }

        Matcher sn = Pattern.compile(
                "<source-translation>(.*?)</source-translation>", Pattern.DOTALL).matcher(text);
        while (sn.find()) {
            Model.Snat s = new Model.Snat();
            s.name = "snat_" + m.snats.size();
            Matcher ip = Pattern.compile("<translated-address>\\s*<member>([^<]+)</member>",
                    Pattern.DOTALL).matcher(sn.group(1));
            if (ip.find()) {
                s.toIp = ip.group(1).trim();
                m.snats.add(s);
            }
        }
    }

    private static String region(String text, String open, String close) {
        int a = text.indexOf(open);
        if (a < 0) return "";
        int b = text.indexOf(close, a);
        if (b < 0) return text.substring(a);
        return text.substring(a, b);
    }

    private static String firstMember(String block, String tag) {
        Matcher m = Pattern.compile("<" + tag + ">\\s*<member>([^<]+)</member>", Pattern.DOTALL)
                .matcher(block);
        return m.find() ? m.group(1).trim() : "";
    }

    private static List<String> members(String block, String tag) {
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("<" + tag + ">(.*?)</" + tag + ">", Pattern.DOTALL)
                .matcher(block);
        if (!m.find()) return out;
        Matcher mm = Pattern.compile("<member>([^<]+)</member>").matcher(m.group(1));
        while (mm.find()) out.add(mm.group(1).trim());
        return out;
    }

    // ================= Cisco ASA =================
    private static void asa(String text, Model m) {
        String objName = null;
        Model.Addr a = null;
        Model.Svc s = null;

        for (String raw : text.split("\n")) {
            String l = raw.trim();
            if (l.length() == 0 || l.startsWith("!") || l.startsWith("#")) continue;
            String low = l.toLowerCase();

            if (low.startsWith("object network ")) {
                objName = l.substring("object network ".length()).trim();
                a = new Model.Addr();
                a.name = objName;
                m.addrs.add(a);
                s = null;
                continue;
            }
            if (low.startsWith("object service ")) {
                objName = l.substring("object service ".length()).trim();
                s = new Model.Svc();
                s.name = objName;
                m.svcs.add(s);
                a = null;
                continue;
            }
            if (low.startsWith("object ") || low.startsWith("access-list ")
                    || low.startsWith("interface ") || low.startsWith("nat ")
                    || low.startsWith("route ")) {
                if (!low.startsWith("object network") && !low.startsWith("object service")) {
                    objName = null;
                }
            }

            if (a != null) {
                if (low.startsWith("subnet ") && tok(l).length >= 3) {
                    String[] t = tok(l);
                    a.type = "net";
                    a.ip = t[1];
                    a.prefix = Model.maskToPrefix(t[2]);
                } else if (low.startsWith("host ") && tok(l).length >= 2) {
                    a.type = "net";
                    a.ip = tok(l)[1];
                    a.prefix = 32;
                } else if (low.startsWith("range ") && tok(l).length >= 3) {
                    a.type = "range";
                    a.ip = tok(l)[1];
                    a.ip2 = tok(l)[2];
                } else if (low.startsWith("fqdn ")) {
                    a.type = "fqdn";
                    a.fqdn = l.substring(5).trim();
                }
            }
            if (s != null && low.startsWith("service ")) {
                String[] t = tok(l);
                if (t.length >= 5) {
                    s.proto = t[1];
                    s.port = t[4];
                }
            }

            // access-list OUT extended permit tcp object A object B eq 80
            if (low.startsWith("access-list ")) {
                String[] t = tok(l);
                if (t.length < 5) continue;
                String aclName = t[1];
                boolean ext = false;
                for (String x : t) if (x.equalsIgnoreCase("extended")) ext = true;
                if (!ext) continue;
                Model.Pol p = new Model.Pol();
                p.name = aclName;
                p.from = aclName;
                p.to = aclName;
                int i = 3;
                p.action = t[i].toLowerCase().startsWith("permit") ? "permit" : "deny";
                i++;
                String proto = t[i].toLowerCase();
                i++;
                // 源
                if (i < t.length && t[i].equalsIgnoreCase("any")) {
                    p.src.add("any");
                    i++;
                } else if (i < t.length && t[i].equalsIgnoreCase("object") && i + 1 < t.length) {
                    p.src.add(t[i + 1]);
                    i += 2;
                } else if (i < t.length && Model.isIp(t[i])) {
                    p.src.add(m.ensureAddr(t[i], 32));
                    i++;
                }
                // 目的
                if (i < t.length && t[i].equalsIgnoreCase("any")) {
                    p.dst.add("any");
                    i++;
                } else if (i < t.length && t[i].equalsIgnoreCase("object") && i + 1 < t.length) {
                    p.dst.add(t[i + 1]);
                    i += 2;
                } else if (i < t.length && Model.isIp(t[i])) {
                    p.dst.add(m.ensureAddr(t[i], 32));
                    i++;
                }
                // 端口
                String port = "";
                if (i < t.length && t[i].equalsIgnoreCase("object") && i + 1 < t.length) {
                    p.svc.add(t[i + 1]);
                } else if (i + 1 < t.length && t[i].equalsIgnoreCase("eq")) {
                    port = t[i + 1];
                    p.svc.add(m.ensureSvc(proto, port));
                } else if (proto.equals("ip")) {
                    p.svc.add("any");
                }
                if (p.svc.isEmpty()) p.svc.add("any");
                m.pols.add(p);
                continue;
            }

            if (low.startsWith("nat (") && a != null) {
                Matcher mt = Pattern.compile("nat\\s*\\(([^)]+)\\)\\s*(static|dynamic)\\s*([0-9.]+)?")
                        .matcher(l);
                if (mt.find()) {
                    String ifs = mt.group(1);
                    String kind = mt.group(2);
                    String ip = mt.group(3);
                    String first = ifs.split(",")[0].trim();
                    if ("static".equals(kind) && ip != null) {
                        if (first.equalsIgnoreCase("outside") || first.equalsIgnoreCase("untrust")) {
                            Model.Dnat d = new Model.Dnat();
                            d.name = a.name + "_dnat";
                            d.extIp = ip;
                            d.intIp = a.ip;
                            if (a.type.equals("net") && a.prefix == 32) m.dnats.add(d);
                        } else {
                            Model.Snat sn = new Model.Snat();
                            sn.name = a.name + "_snat";
                            sn.src = a.name;
                            sn.toIp = ip;
                            m.snats.add(sn);
                        }
                    }
                }
                continue;
            }
        }
    }
}
